var path = require('path'),
    express = require('express'),
    config = require('./config');

var debug = require('debug');
var error = debug('express:error');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'jade');

if (!config.staticstore) app.use(express.static(path.join(__dirname, 'public')));


// 加载中间件
app.use(require('./middlewares')(app));

// 加载路由
app.use(require('./routes')(app));

/// catch 404 and forward to error handler
app.use(function NotFound(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;

    next(err);

});

// no stacktraces leaked to user
app.use(function InternalServerError(err, req, res, next) {
    error(err.message.red);

    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        status: err.status,
        error: process.env.NODE_ENV === 'production' ? null : err
    });

});

app.disable('x-powered-by');

module.exports = app;
