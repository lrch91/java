## 环信 WebIM sdk

测试环信WebIM请访问 https://webim.easemob.com。

更多关于环信的开发文档请见：https://docs.easemob.com
