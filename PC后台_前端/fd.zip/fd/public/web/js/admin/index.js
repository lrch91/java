require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var lockURL = '/api/fdmanage/authority/lockManager', //封号
        unlockURL = '/api/fdmanage/authority/unlockManager'; //解封


    var deleteURL = '/api/fdmanage/authority/delManager'; //删除

    $(function() {
        var message = $('#message');

        var changOprt = function(id, type, dom) {
            var $status = dom.parents('td').siblings('.status');

            $.post(type ? lockURL : unlockURL, {
                userId: id
            }, function(data) {
                if (data.status === 'success') {
                    //操作成功
                    if (type) {
                        dom.removeClass('lock am-text-success').addClass('unlock am-text-danger').html('<span class="am-icon-lock"></span> 禁用');


                    } else {
                        dom.removeClass('unlock am-text-danger').addClass('lock am-text-success').html('<span class="am-icon-unlock"></span> 启用');

                    };

                } else {
                    message.html(g.error(data.msg));

                };

            });

        };

        // 封号 解封
        $('.status').on('click', '.lock', function() {
            var $this = $(this);

            var id = $this.attr('data-id');

            changOprt(id, true, $this);


        }).on('click', '.unlock', function() {
            var $this = $(this);

            var id = $this.attr('data-id');

            changOprt(id, false, $this);

        });

        $('.delete').click(function() {
            var id = $(this).attr('data-id');

            if (confirm('确认删除该管理员？')) {
                $.post(deleteURL, {
                    userId: id
                }, function(data) {
                    if (data.status === 'success') {
                        $('.id-' + id).remove();

                    } else {
                        message.html(g.error(data.msg));

                    };

                });

            }

        });


    });

});
