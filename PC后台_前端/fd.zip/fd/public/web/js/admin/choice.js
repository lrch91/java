require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min'
    }
});

require(['jquery'], function($) {
    $(function() {
        $('.check').click(function() {
            opener.dismissRelatedLookupPopup(window, $(this).attr('data-userId'));

        });

    });

});
