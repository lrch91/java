require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min',
        'CKEDITOR': 'ckeditor/ckeditor',
        'wangEditor': 'wangEditor/js/wangEditor-1.3.12.min',
        'plupload': 'wangEditor/js/plupload.full.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
         'amazeui' : ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'wangEditor', 'plupload'], function($, events, g) {
    var getTokenURL = '/api/fdonline/getqiniutoken';
    var uploadURL = 'http://up.qiniu.com/';
    var addGoodsURL = '/api/fdmanage/article/addArticle';
    var updateGoodsURL = '/api/fdmanage/article/editArticle';

    $(function() {
        var message = $('#message');
        var formNode = $('#article-form');
        var zone = $('#image-zone');
        var editor;

        $('#add-groups').click(function() {
            var formData = {};
            var id = $(this).attr('data-id');
            var typeid = $("#type_id").val();
            var backurl = '';
            formData = g.serialize(formNode);
            if(typeid=="home"){
                 backurl = '/article/home/';
                 formData.type = '资讯头条'
            }else if(typeid=="fertilizer"){
                 backurl = '/article/fertilizer/';
                 formData.type = '化肥热点'
            }else if(typeid=="farmer"){
                 backurl = '/article/farmer/'
                 formData.type = '农化热点'
            }else if(typeid=="server"){
                 backurl = '/article/server/'
                 formData.type = '服务资讯'
            }else if(typeid=="crops"){
                 backurl = '/article/crops/'
                 formData.type = '作物指导'
            }else if(typeid=="help"){
                 backurl = '/article/help/'
                 formData.type = '帮助中心'
            }else if(typeid=="member"){
                 backurl = '/article/member'
                 formData.type = '会员中心'
            }

            id && (formData['id'] = id);
            console.log(formData);
            $.post(id ? updateGoodsURL : addGoodsURL, formData, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));
                    g.redirect(backurl);

                } else {
                    message.html(g.error(data.msg));

                }

            });

        });

        $('form #image-zone').on('click', '.am-close', function(event) {
            event.preventDefault();
            zone.empty();

        });

        var editor = $('#editor').wangEditor({
            //重要：传入 uploadImgComponent 参数，值为 $uploadContainer
            uploadImgComponent: $('#uploadContainer')
        });

        g.getToken(getTokenURL, function(data) {

            events.emit('editor', data);
            events.emit('uploadGoodsImg', data);

        });

        events.on('editor', function(data) {
            var token = {
                token: data.token
            };

            //实例化一个上传对象
            var uploader = new plupload.Uploader({
                browse_button: 'btnBrowse',
                url: uploadURL,
                // flash_swf_url: 'plupload/Moxie.swf',
                // sliverlight_xap_url: 'plupload/Moxie.xap',
                multipart_params: token,
                multi_selection: false,
                filters: {
                    mime_types: [
                        //只允许上传图片文件 （注意，extensions中，逗号后面不要加空格）
                        {
                            title: "图片文件",
                            extensions: "jpg,gif,png,bmp"
                        }
                    ]
                }
            });

            //初始化
            uploader.init();

            //绑定文件添加到队列的事件
            uploader.bind('FilesAdded', function(uploader, files) {
                uploader.start();

            });

            //单个文件上传之后
            uploader.bind('FileUploaded', function(uploader, file, responseObject) {
                editor.command(event, 'insertHTML', '<img src="' + 'http://ulishop.qiniudn.com/' + JSON.parse(responseObject.response).key + '"/>');

            });

        });

        events.on('uploadGoodsImg', function(data) {
            var token = data.token;

            $('input#image').change(function() {

                var file = $(this)[0].files[0];
                if (file && file !== undefined) {
                    g.upload(file, token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                    });

                }

            });

        });

        events.on('upload', function(data, token) {

            zone.empty().append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            })).append($('<input>', {
                type: 'hidden',
                name: 'imagePath',
                value: data.key
            })).append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key
            }));

        });
    });

});
