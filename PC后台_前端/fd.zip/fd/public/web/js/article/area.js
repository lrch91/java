require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui' : ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {

    var delArticleURL = '/api/mgms/article/delArticle';
    var topArticleURL = '/api/mgms/article/articleSetTop';
    $(function() {
        var message = $('#message');

        $('table').on('click', '.delete', function(event) {
            event.preventDefault();
            var pTR = $(this).parents('tr');
            var id = pTR.attr('data-id');

            $.post(delArticleURL, {
                id: id
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));
                    pTR.remove();

                } else {
                    message.html(g.error(data.msg));

                }
            });


        }).on('click', '.gotop', function(event) {
            event.preventDefault();
            var pTR = $(this).parents('tr');
            var id = pTR.attr('data-id');

            $.post(topArticleURL, {
                id: id
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));
                    location.reload();

                } else {
                    message.html(g.error(data.msg));

                }
            });


        });

    });

});
