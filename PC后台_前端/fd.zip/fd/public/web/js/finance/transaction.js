require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var menualRechargeURL = '/api/mgms/memberBalance/menualRecharge';
    $(function() {
        var message = $('#message');

        $('.am-table').on('click', ".add", function() {
            var id = $(this).attr('data-id');
            $('#add').modal({
                width: 650,
                relatedTarget: $(this),
                onConfirm: function(e) {
                    var put = {};
                    put.userId = id;
                    put.sum = $('#addmoney').val();
                    put.remark = $('#addmark').val();
                    if (put.sum == '') {
                        $('.addmsg').html('请填金额');
                        setTimeout(function() {
                            $('.addmsg').html('');
                        }, 2000);
                        return false;
                    }
                    if (put.remark == '') {
                        $('.addmsg').html('请填写备注');
                        setTimeout(function() {
                            $('.addmsg').html('');
                        }, 2000);
                        return false;
                    }
                    $.post(menualRechargeURL, put, function(data) {
                        if (data.status === 'success') {
                            message.html(g.success(data.msg));
                            setTimeout(function() {
                                g.reload();
                            }, 2000);
                        } else {
                            message.html(g.error(data.msg));

                        }

                    });
                    $('#add').modal('close');
                },
                closeOnConfirm: false
            }).on('closed.modal.amui', function() {
                $('#change-address-modal input').val('');
                $('#change-address-modal select').empty('');
            });

        }).on('click', ".Reduction", function() {
            var id = $(this).attr('data-id');
            $('#Reduction').modal({
                width: 650,
                relatedTarget: $(this),
                onConfirm: function(e) {
                    var put = {};
                    put.userId = id;
                    put.sum = 0 - $('#reducemoney').val();
                    put.remark = $('#reducemark').val();
                    if (put.sum == '') {
                        $('.reducemsg').html('请填金额');
                        setTimeout(function() {
                            $('.reducemsg').html('');
                        }, 2000);
                        return false;
                    }
                    if (put.remark == '') {
                        $('.reducemsg').html('请填写备注');
                        setTimeout(function() {
                            $('.reducemsg').html('');
                        }, 2000);
                        return false;
                    }
                    $.post(menualRechargeURL, put, function(data) {
                        if (data.status === 'success') {
                            message.html(g.success(data.msg));
                            setTimeout(function() {
                                g.reload();
                            }, 2000);

                        } else {
                            message.html(g.error(data.msg));

                        }

                    });
                    $('#Reduction').modal('close');
                },
                closeOnConfirm: false
            }).on('closed.modal.amui', function() {
                $('#change-address-modal input').val('');
                $('#change-address-modal select').empty('');
            });

        });


    });

});
