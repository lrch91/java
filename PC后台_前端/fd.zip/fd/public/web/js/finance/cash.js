require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {

    var refuseURL = '/api/mgms/trade/unPassWithdraw';
    var passURL = '/api/mgms/trade/passWithdraw';
    var finishURL = '/api/mgms/trade/finishWithdraw';

    $(function() {
        var startDate = '',
            endDate = '',
            message = $('#message');

        $('#screening-date-start').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).
        on('changeDate.datepicker.amui', function(event) {
            startDate = new Date(event.date);

            if (endDate != '' && (event.date.valueOf() > endDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });

        $('#screening-date-end').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).
        on('changeDate.datepicker.amui', function(event) {
            endDate = new Date(event.date);

            if (startDate != '' && (event.date.valueOf() < startDate.valueOf())) {

                message.html(g.error('结束日期应大于开始日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });


        $('a#admin-refuse').bind('click', function(event) {

            $('#admin-refuse-confirm').modal({
                relatedTarget: this,
                onConfirm: function(e) {
                    var id = $(this.relatedTarget).parent().attr('id');

                    $.post(refuseURL, {
                        id: id,
                        remark: e.data
                    }, function(data) {
                        if (data.status === 'success') {
                            g.redirect('/finance/cash/', 500);

                        } else {
                            message.html(g.error(data.msg));

                        }

                    });

                },
                onCancel: function(e) {

                }
            });

        });


        $('a#admin-pass').bind('click', function(event) {

            $('#admin-pass-confirm').modal({
                relatedTarget: this,
                onConfirm: function(e) {
                    var id = $(this.relatedTarget).parent().attr('id');

                    $.post(passURL, {
                        id: id
                    }, function(data) {
                        if (data.status === 'success') {
                            g.redirect('/finance/cash/', 500);

                        } else {
                            message.html(g.error(data.msg));

                        }

                    });

                },
                onCancel: function(e) {

                }
            });

        });


        $('a#admin-finish').bind('click', function(event) {

            $('#admin-finish-confirm').modal({
                relatedTarget: this,
                onConfirm: function(e) {
                    var id = $(this.relatedTarget).parent().attr('id');

                    $.post(finishURL, {
                        id: id,
                        number: e.data
                    }, function(data) {
                        if (data.status === 'success') {
                            g.redirect('/finance/cash/', 500);

                        } else {
                            message.html(g.error(data.msg));

                        }

                    });

                },
                onCancel: function(e) {

                }
            });
        });


        $('a#admin-look').bind('click', function(event) {

        });


    });

});
