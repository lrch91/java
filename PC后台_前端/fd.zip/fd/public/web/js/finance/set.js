require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'g', 'RelatedObjectLookups', 'jquery.validate','amazeui'], function($, g, RelatedObjectLookups) {
    var updateParamURL = '/api/fdmanage/trade/updateParam';

    $(function() {
        var message = $('#message');
        /*$('#from').validate({
            rules: {
                loginName: {
                    required: true
                },
                department: {
                    required: true
                },
                loginname: {
                    required: true
                },
                state: {
                    required: true
                }
            },
            messages: {
                loginName: {
                    required: '请输入用户账号'
                },
                department: {
                    required: '请输入直属部门'
                },
                state: {
                    required: '请选择状态'
                }
            },
            errorPlacement: function(error, element) {
                message.html(g.error(error.text()));

            },
            submitHandler: function(form) {
                var data = g.serialize(form);

                $.post(addAdminURL, data, function(_data) {
                    if (_data.status === 'success') {
                        message.html(g.success(_data.msg));

                        g.redirect('/admin/');

                    } else {
                        message.html(g.error(_data.msg));

                    };

                }, 'json');

                return false;

            }

        });*/

        $('.btn-save').on('click', function() {
            var data = g.serialize($('#from'));
            console.log(data);
            $.post(updateParamURL, data, function(_data) {
                if (_data.status === 'success') {
                    message.html(g.success(_data.msg));

                    g.redirect('/finance/set');

                } else {
                    message.html(g.error(_data.msg));

                };

            }, 'json');
            return false;
        })

    });

});
