require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var passURL = '/api/mgms/trade/passRecharge';
    var confuseURL = '/api/mgms/trade/unPassRecharge';

    $(function() {
        var startDate = '',
            endDate = '',
            message = $('#message');

        $('table').on('click', '#pass', function() {
            var $this = $(this);
            var id = $this.parents('tr').attr('data-id');

            if (id && id !== '' && confirm('确认通过用户的充值请求？')) {
                $.post(passURL, {
                    id: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        g.reload();

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            }

        }).on('click', '#confuse', function() {
            var $self = $(this);

            $('#confuse-modal').modal({
                width: 650,
                relatedTarget: $(this),
                onConfirm: function(e) {
                    var put = g.serialize($('#confuse-modal'));
                    var id = $self.parents('tr').attr('data-id');

                    if (!put.remark || put.remark === '') {
                        message.html(g.error('请选择拒绝理由!!!'));
                        return false;
                    }

                    if (id && id !== '') {
                        put.id = id;

                        $.post(confuseURL, put, function(data) {
                            if (data.status === 'success') {
                                message.html(g.success(data.msg));
                                g.reload();

                            } else {
                                message.html(g.error(data.msg));

                            }

                        });
                    }

                }
            });

        });

        $('#screening-date-start').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).
        on('changeDate.datepicker.amui', function(event) {
            startDate = new Date(event.date);

            if (endDate != '' && (event.date.valueOf() > endDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });

        $('#screening-date-end').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).
        on('changeDate.datepicker.amui', function(event) {
            endDate = new Date(event.date);

            if (startDate != '' && (event.date.valueOf() < startDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });


    });

});
