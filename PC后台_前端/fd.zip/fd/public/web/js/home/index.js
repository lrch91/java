require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    $(function() {


    });

});
