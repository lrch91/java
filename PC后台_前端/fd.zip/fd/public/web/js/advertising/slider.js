require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui' : ['jquery']
    }
});

require(['jquery', 'events', 'g', 'account/account', 'amazeui'], function($, events, g, account) {
    var setAdTopURL = '/api/mgms/ad/setAdTop';
    var delAdURL = '/api/fdmanage/adv/delAdv';
    $(function() {
        var message = $('#message');

        $('table tbody').on('click', '#top-ad', function(event) {
            event.preventDefault();
            var dom = $(this);
            var id = dom.parents('tr').attr('data-id');

            $.post(setAdTopURL, {
                id: id
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.parents('tbody').prepend(dom.parents('tr'));
                    // g.reload(500);

                } else {
                    message.html(g.error(data.msg));

                }

            });

        }).on('click', '.del-ad', function(event) {
            event.preventDefault();
            var dom = $(this);
            var id = dom.parents('tr').attr('data-id');

            if (id && confirm('确定删除该广告吗？')) {
                $.post(delAdURL, {
                    advId: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        dom.parents('tr').remove();
                        // g.reload(500);

                    } else {
                        message.html(g.error(data.msg));

                    }

                });

            }

        });

    });

});
