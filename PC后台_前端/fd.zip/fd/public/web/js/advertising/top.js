require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var getTokenURL = '/api/mgms/common/get_token';
    var uploadURL = 'http://up.qiniu.com/';
    var addGoodsURL = '/api/mgms/ad/addAd';
    var updateGoodsURL = '/api/mgms/ad/editAd';

    $(function() {
        var message = $('#message');
        var formNode = $('form');
        var zone = $('#image-zone');
        var editor;

        $('#add-ad').click(function() {
            var formData = {};
            var id = $(this).attr('data-id');

            formData = g.serialize(formNode);

            id && (formData['id'] = id);

            $.post(id ? updateGoodsURL : addGoodsURL, formData, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    if (!id)
                        g.reload(500);

                } else {
                    message.html(g.error(data.msg));

                }

            });

        });

        $('form #image-zone').on('click', '.am-close', function(event) {
            event.preventDefault();

            zone.empty();

        });

        g.getToken(getTokenURL, function(data) {
            events.emit('uploadGoodsImg', data);

        });

        events.on('uploadGoodsImg', function(data) {
            var token = data.token;

            $('input#image').change(function() {
                var file = $(this)[0].files[0];

                if (file && file !== undefined) {
                    g.upload(file, token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                    });

                }

            });

        });

        events.on('upload', function(data, token) {
            zone.empty().append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            })).append($('<input>', {
                type: 'hidden',
                name: 'img_path',
                value: data.key
            })).append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key
            }));

        });

    });

});
