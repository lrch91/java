require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'bootstrap': ['jquery'],
        'jquery.base64':['jquery']
    }
});

require(['jquery', 'events', 'g', 'jquery.validate','jquery.base64'], function($, events, g) {
    $(function() {
        //产生4位随机数
        function getfouth() {
            var value='',i;
            for (j = 1; j <= 4; j++) {
                i = Math.floor(Math.random()*10); 
                value = value + i;
            }
            return value;
        }
        //validate验证
        var form = $("#loginform");
        var message = $("#info");
        var next = $("#next").val();
        var loginURL = '/api/fdmanage/common/login';
        var getLoginSessionStateURL = '/api/user/getLoginSessionState';

        function setCookie(name, value) {
            var Days = 30;
            var exp = new Date();
            exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
            document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
        }
        form.validate({
            rules: {
                imgcode: {
                    required: true,
                    minlength: 4,
                    maxlength: 4
                },
                loginstr: {
                    required: true
                },
                password: {
                    required: true,
                    minlength: 6,
                    maxlength: 20
                }
            },
            messages: {
                imgcode: {
                    required: '请输入图形验证码',
                    minlength: '请输入正确的图形验证码',
                    maxlength: '请输入正确的图形验证码'
                },
                loginstr: {
                    required: '请输入您的用户名/邮箱/或手机号码'
                },
                password: {
                    required: '请输入登录密码',
                    maxlength: '密码最多输入 20 位',
                    minlength: '密码最少输入 6 位',
                }
            },
            errorPlacement: function(error, element) {
                message.html(error.text());
                return false;
            },
            success: function(error, element) {

                message.html("");

            },
            submitHandler: function(form) {
                /*events.on('login', function() {
                    g.redirect(next);

                });

                g.login(g.serialize(form, data), function(_data) {
                    if (_data.status === 'success') {
                        message.html(g.message.success(_data.msg));

                    } else {
                        message.html(g.message.error(_data.msg));
                        $('.marr').trigger('click');

                    }

                });*/
                /*$.post(loginURL, g.serialize(form, data), function(_data) {
                    if (_data.status === 'success') {
                        console.log(_data.cookievalue);
                        $.post(getLoginSessionStateURL, {
                            id: _data.cookievalue
                        }, function(data) {
                            message.html(_data.msg);
                            setCookie('MGSESSIONID', _data.cookievalue);
                            g.redirect(next);
                        })

                    } else {
                        message.html(_data.msg);
                        $('.marr').trigger('click');

                    }
                })*/
                var updata = g.serialize(form);
                updata.loginStr = getfouth() + updata.loginStr + getfouth();
                updata.password = getfouth() + updata.password + getfouth();

                updata.loginStr=$.base64.encode(updata.loginStr);
                updata.password=$.base64.encode(updata.password);
                updata.ip = returnCitySN["cip"]
                $.post(loginURL, updata, function(_data) {
                    if (_data.status === 'success') {
                        message.html(_data.msg);
                        g.redirect(next);

                    } else {
                        message.html(_data.msg);
                        $('.marr').trigger('click');

                    }
                })

            }

        });

    })

});
