require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var delArticleURL = '/api/fdmanage/game/delPhotoSpots';
    var setArticleTopURL = '/api/fdmanage/game/setPhotoSpotsTop';
    $(function() {
        var message = $('#message');
        $('.delete').on('click', function() {
            var id = $(this).attr('data-id')
            if (confirm('是否删除！')) {
                $.post(delArticleURL, {
                    photoSpotsId: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        g.reload(500);

                    } else {
                        message.html(g.error(data.msg));

                    }
                })
            }
        })

        $('.gotop').on('click',function(){
            var id = $(this).attr('data-id');
            $.post(setArticleTopURL, {
                    photoSpotsId: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        g.reload(500);

                    } else {
                        message.html(g.error(data.msg));

                    }
                })
        })

    });

});
