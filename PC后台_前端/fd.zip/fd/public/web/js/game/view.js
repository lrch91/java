require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min',
        'CKEDITOR': 'ckeditor/ckeditor',
        'wangEditor': 'wangEditor/js/wangEditor-1.3.12.min',
        'plupload': 'wangEditor/js/plupload.full.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'wangEditor', 'plupload'], function($, events, g) {
    var getTokenURL = '/api/fdonline/getqiniutoken';
    var uploadURL = 'http://up.qiniu.com/';
    var addGoodsURL = '/api/fdmanage/game/editPhotoSpots';

    $(function() {
        var message = $('#message');
        var formNode = $('#article-form');
        var zone = $('#image-zone');
        var zone1 = $('#image-zone1');
        var editor;

        $('#add-groups').click(function() {
            var formData = {};
            var id = $(this).attr('data-id');
            var typeid = $("#type_id").val();
            formData = g.serialize(formNode);
            formData.imagePath = formData.imagePath.join('|');
            formData.id = id;
            console.log(formData);
            $.post(addGoodsURL, formData, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));
                    g.redirect('/game');

                } else {
                    message.html(g.error(data.msg));

                }

            });

        });

        $('form #image-zone').on('click', '.am-close', function(event) {
            event.preventDefault();
            zone.empty();
            $('.tag-box').empty();
            $('.image-zone').find('.rects-all').empty();
            $('.image-zone').find('.rects').empty();

        });
        $('form #image-zone1').on('click', '.am-close', function(event) {
            event.preventDefault();
            zone1.empty();
            $('.tag-box').empty();
            $('.image-zone').find('.rects-all').empty();
            $('.image-zone').find('.rects').empty();

        });


        g.getToken(getTokenURL, function(data) {

            events.emit('editor', data);
            events.emit('uploadGoodsImg', data);

        });

        events.on('editor', function(data) {
            var token = data.token;

            $('input#image').change(function() {

                var file = $(this)[0].files[0];
                if (file && file !== undefined) {
                    g.upload(file, token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                    });

                }

            });
        });

        events.on('uploadGoodsImg', function(data) {
            var token = data.token;

            $('input#image1').change(function() {

                var file = $(this)[0].files[0];
                if (file && file !== undefined) {
                    g.upload(file, token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload1', JSON.parse(this.responseText), token);

                    });

                }

            });

        });

        events.on('upload', function(data, token) {

            zone.empty().append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            })).append($('<input>', {
                type: 'hidden',
                name: 'imagePath[]',
                value: data.key
            })).append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key
            })).append($('<div>', {
                class: 'rects-all',
            })).append($('<div>', {
                class: 'rects',
            }));

        });
        events.on('upload1', function(data, token) {

            zone1.empty().append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            })).append($('<input>', {
                type: 'hidden',
                name: 'imagePath[]',
                value: data.key
            })).append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key
            })).append($('<div>', {
                class: 'rects-all',
            })).append($('<div>', {
                class: 'rects',
            }));

        });

        var rectsx = 0;
        var rectsy = 0;
        var rectsdom = '';
        //画矩形
        $('.image-zone').on('mousedown', '.rects', function(ev) {
                var offset = $(this).offset();
                rectsx = offset.left;
                rectsy = offset.top;
                rectsdom = $(this);
                recordPoint(ev);
            })
            //----------------------------------------------------------
            //
            //
            /**
                画点
            */
        function makedot(x, y) {
            pointDiv = "<div style='height:1px;position:absolute;left:" + (x - rectsx) +
                "px;top:" + (y - rectsy) + "px;width:1px;background:#f00;overflow:hidden'></div>";
            return pointDiv;
        }
        /**  
          函数功能：根据指点矩形左上角坐标及长宽绘制矩形。  
          函数思路：根据左上坐标及长宽，计算横纵向边每点的坐标  
        */
        function rect(x, y, w, h) { //(x,y)左上角坐标,w,h 宽与高 
            var points = "";
            for (var i = 0; i < w; i++) {
                points += makedot(x + i, y);
                points += makedot(x + i, y + h);
            }
            for (var i = 0; i < h; i++) {
                points += makedot(x, y + i);
                points += makedot(x + w, y + i);
            }
            //var container = document.getElementById("container");
            rectsdom.html(points)
                //container.innerHTML = points;
        }
        /**
            获取鼠标位置
        */
        function mousePosition(ev) {
            ev = ev || window.event;
            if (ev.pageX || ev.pageY) {
                return {
                    x: ev.pageX,
                    y: ev.pageY
                };
            }
            var doc = document.documentElement,
                body = document.body;
            var pageX = event.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0);
            var pageY = event.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc && doc.clientTop || body && body.clientTop || 0);
            return {
                x: pageX,
                y: pageY
            };
        }

        //开始点坐标
        var startPoint = null;
        //记录鼠标事件
        var moveEvent;
        var upEvent;
        /**
            记录开始点，注册鼠标事件
        */
        function recordPoint(ev) {
            var point = mousePosition(ev);
            startPoint = point;

            moveEvent = document.body.onmousemove;
            upEvent = document.body.onmouseup;

            document.body.onmousemove = drawRect;
            document.body.onmouseup = endDraw;
        }
        /**
            画矩形
        */
        function drawRect(ev) {
            var point = mousePosition(ev);
            rect(startPoint.x, startPoint.y, Math.abs(point.x - startPoint.x), Math.abs(point.y - startPoint.y));
        }
        /**
            结束动作
        */
        function endDraw(ev) {
            var endPosit = mousePosition(ev);
            var topP = startPoint.y - rectsy;
            var leftP = startPoint.x - rectsx;
            var widthP = endPosit.x - startPoint.x;
            var heightP = endPosit.y - startPoint.y;
            console.log(rectsx, startPoint.x, topP, leftP);
            var indexNum = parseInt($('.tag-box').attr('index')) || 0;
            $('.tag-box').attr('index', (indexNum + 1));
            var rectDiv = "<div index=" + indexNum + " style='height:" + heightP + "px;position:absolute;left:" + leftP +
                "px;top:" + topP + "px;width:" + widthP + "px;border:1px solid #f00;overflow:hidden'><input name=spots[] type=hidden value=" + (topP + '|' + leftP + '|' + widthP + '|' + heightP) + "><p>" + indexNum + "</p></div>";
            var rectDiv1 = "<div index=" + indexNum + " style='height:" + heightP + "px;position:absolute;left:" + leftP +
                "px;top:" + topP + "px;width:" + widthP + "px;border:1px solid #f00;overflow:hidden'><p>" + indexNum + "</p></div>";
            var tagHtml = '<a class="am-btn am-btn-default tag">' + indexNum + '</a>';
            $('.tag-box').append(tagHtml);
            $('#image-zone').find('.rects-all').append(rectDiv);
            $('#image-zone1').find('.rects-all').append(rectDiv1);
            //console.log(startPoint,endPosit);
            rectsdom.html('');
            document.body.onmousemove = '';
            document.body.onmouseup = '';
        }

        //-----------删除--------
        $('.tag-box').on('click', '.tag', function() {
            var num = $(this).html();
            $('.image-zone').find('div').each(function() {
                var index = $(this).attr('index');
                if (index == num) {
                    $(this).remove();
                }
            })
            $(this).remove();
        })
    });

});
