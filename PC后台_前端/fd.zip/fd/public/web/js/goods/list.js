require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'account/account', 'amazeui'], function($, events, g, account) {
    var changeGoodsStatusURL = '/api/fdmanage/goods/setGoodsDeleted';
    var setGoodsUp = '/api/fdmanage/goods/setGoodsUp';
    var setGoodsDown = '/api/fdmanage/goods/setGoodsDown';

    $(function() {
        var message = $('#message');

        var changStatus = function(id, url, type, dom) {

            $.post(url, {
                goodsId: id
            }, function(data) {
                if (data.status === 'success') {
                    //操作成功
                    if (type) {
                        dom.removeClass('goods-yes adicon-alert-success').addClass('goods-no adicon-alert-error');

                    } else {
                        dom.removeClass('goods-no adicon-alert-error').addClass('goods-yes adicon-alert-success');

                    };

                } else {
                    alert(data.msg);

                };

            });

        };

        $('table tbody').on('click', '.goods-yes', function(event) {
            event.preventDefault();
            var id = $(this).attr('data-id');

            changStatus(id,setGoodsDown, true, $(this));
        }).on('click', '.goods-no', function(event) {
            event.preventDefault();
            var id = $(this).attr('data-id');

            changStatus(id, setGoodsUp, false, $(this));
        }).on('click', '.goods-del', function(event) {
            event.preventDefault();
            var id = $(this).parents('td').attr('id');
            var dom = $(this);

            $.post(changeGoodsStatusURL, {
                goodsId: id
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.parents('tr').remove();

                    // g.redirect('/goods/list/');

                } else {
                    message.html(g.error(data.msg));

                }

            });
        });

    });

});
