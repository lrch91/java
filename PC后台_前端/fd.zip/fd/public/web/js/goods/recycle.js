require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'account/account', 'amazeui'], function($, events, g, account) {

    var changeGoodsStatusURL = '/api/mgms/goods/goods_status';
    var deleteGoodsURL = '/api/mgms/goods/recycleClear';
    var message = $('#message');

    $(function() {

        $('table tbody').on('click', '#goods-back', function(event) {
            event.preventDefault();
            var id = $(this).parents('td').attr('id');
            var dom = $(this);

            $.post(changeGoodsStatusURL, {
                goods_id: id,
                status: 'down'
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.parents('tr').remove();

                    // g.redirect('/goods/list/');

                } else {
                    message.html(g.error(data.msg));

                }
            });

        }).on('click', '#goods-del', function(event) {
            event.preventDefault();
            var id = $(this).parents('td').attr('id');
            var dom = $(this);

            if (confirm("是否确认删除？")) {
                $.post(deleteGoodsURL, {
                    id: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        dom.parents('tr').remove();

                        // g.redirect('/goods/list/');

                    } else {
                        message.html(g.error(data.msg));

                    }
                })
            }

        });
    });

});
