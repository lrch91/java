require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery'],
        'jquery.treemenu': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'account/account', 'amazeui', 'jquery.treemenu'], function($, events, g, account) {

    var addCategoryURL = '/api/fdmanage/goods/addCategory';
    var updateCategoryURL = '/api/fdmanage/goods/editCategory';
    var goTopURL = '/api/fdmanage/goods/setCategoryTop';
    var delCategoryURL = '/api/fdmanage/goods/delCategory';

    $(function() {
        var message = $('#message');

        $(".tree").treemenu({
            delay: 300
        }).openActive();
        var addNewHtml = '<li class="li-add"><span class="level-name"><input type="text" name="name"></span><span class="level-op"><button class="am-btn saveCate am-btn-primary am-btn-xs">保存</button></span></li>';
        $('.addFirstLevel').on('click', function() {
                $('.tree').append(addNewHtml);
            })
            /*$('.normal').on('click',function(){
                alert(00)
            })*/
        $('.tree-box').on("click", ".saveCate", function() {
            var self = this;
            var pid = $(this).attr('data-pid') || '';
            var name = $(this).parents('li.li-add').find('input').val();
            console.log(name);
            $.post(addCategoryURL, {
                name: name,
                parentId: pid
            }, function(data) {
                if (data.status === 'success') {
                    $(self).parents('li').remove();
                    message.html(g.success(data.msg));
                    g.reload(500);

                } else {
                    message.html(g.error(data.msg));

                }
            })
        }).on("click", ".delete", function() {
            var id = $(this).attr('id')
            if (confirm("确认删除？")) {
                $.post(delCategoryURL, {
                    categoryId: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        g.reload(500);

                    } else {
                        message.html(g.error(data.msg));

                    }
                })
            }
        })/*on('click', '.addmore', function(event) {
            event.stopPropagation();
            var pli = $(this).parents('li');
            var pid = pli.attr('id');
            var ul = pli.find('.level2');
            console.log(ul);
            if (!ul.length) {
                pli.append('<ul class="level2"></ul>')
            }
            var addhtml = '<li class="li-add"><span class="level-name"><input type="text" name="name"></span><span class="level-op"><button class="am-btn saveCate am-btn-primary am-btn-xs" data-pid=' + pid + '>保存</button></span></li>';
            pli.find('.level2').append(addhtml);
            return false
        }).on('click', '.edit', function(event) {
            event.stopPropagation();
            var pli = $(this).parents('li');
            $(this).parents('.normal').css('display', 'none').next().css('display', 'inline-block');
            //pli.find('.edit-box').css('display','block')
        })*/.on('click', '.cencel', function() {
            $(this).parents('.edit-box').css('display', 'none').prev().css('display', 'inline-block');
        }).on('click', '.seve-edit', function() {
            var id = $(this).attr('id');
            var name = $(this).parents('.edit-box').find('input').val();
            $.post(updateCategoryURL, {
                id: id,
                name: name
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));
                    g.reload(500);

                } else {
                    message.html(g.error(data.msg));

                }
            })
        })

        $('.gotop').on('click',function(){
            var id = $(this).attr('data-id');
            $.post(goTopURL, {
                    categoryId: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        //g.reload(500);

                    } else {
                        message.html(g.error(data.msg));

                    }
                })
        })
    });

});
