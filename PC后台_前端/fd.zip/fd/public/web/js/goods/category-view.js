require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var getTokenURL = '/api/fdonline/getqiniutoken';
    var uploadURL = 'http://up.qiniu.com/';
    var addGoodsURL = '/api/fdmanage/goods/addCategory';
    var updateGoodsURL = '/api/fdmanage/goods/editCategory';

    function GetQueryString(name) {

        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");

        var r = window.location.search.substr(1).match(reg);

        if (r != null) return unescape(r[2]);
        return null;

    }
    function getQueryString(key){
        var reg = new RegExp("(^|&)"+key+"=([^&]*)(&|$)");
        var result = window.location.search.substr(1).match(reg);
        return result?decodeURIComponent(result[2]):null;
      }
    $(function() {
        var message = $('#message');
        var zone = $('#image-zone');
        var editor;
        var categoryName = getQueryString('name');
        var categoryimg = GetQueryString('img') || '';
        if(categoryName){
            $('#name').val(categoryName)
        }
        if(categoryimg && categoryimg!='undefined'){
            var imghtml = '<a class="am-close am-icon-close" href="javascript:;"></a>'+
                          '<input type="hidden" name="imagePath" value="'+categoryimg+'">'+
                          '<img class="am-thumbnail" src="http://ulishop.qiniudn.com/'+categoryimg+'">';
            $('#image-zone').html(imghtml);
        }
        $('#add-ad').click(function() {
            var name = $('#name').val();
            var img = $('#image-zone').find('input').val();
            var id = GetQueryString('id') || '';
            var pid = GetQueryString('pid') || '';
            if (id) {
                $.post(updateGoodsURL,{id:id,name:name,imagePath:img}, function(data) {
                    console.log(data);
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        g.redirect('/goods/category/');

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            } else {
                $.post(addGoodsURL,{parentId:pid,name:name,imagePath:img}, function(data) {
                    console.log(data);
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        g.redirect('/goods/category/');

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            }


        });

        $('form #image-zone').on('click', '.am-close', function(event) {
            event.preventDefault();

            zone.empty();

        });

        g.getToken(getTokenURL, function(data) {
            events.emit('uploadGoodsImg', data);

        });

        events.on('uploadGoodsImg', function(data) {
            var token = data.token;

            $('input#image').change(function() {
                var file = $(this)[0].files[0];

                if (file && file !== undefined) {
                    g.upload(file, token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                    });

                }

            });

        });

        events.on('upload', function(data, token) {
            zone.empty().append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            })).append($('<input>', {
                type: 'hidden',
                name: 'imagePath',
                value: data.key
            })).append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key
            }));

        });

    });

});
