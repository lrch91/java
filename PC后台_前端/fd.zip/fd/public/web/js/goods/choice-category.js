require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min'
    }
});

require(['jquery'], function($) {
    $(function() {

        $('.check').click(function() {
            var name = $(this).attr('name');
            var id = $(this).attr('data-id');
            var str = id+'|'+name;

            opener.dismissRelatedLookupPopupWithUnique(window, str);

        });

    });

});
