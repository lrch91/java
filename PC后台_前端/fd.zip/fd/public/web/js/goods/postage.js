require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'jquery.ui.widget': 'jquery/jquery.ui.widget',
        'jquery.fileupload': 'jquery/jquery.fileupload',
        'amazeui': 'amazeui.min'

    },
    shim: {
        'jquery.validate': ['jquery'],
        'jquery.ui.widget': ['jquery'],
        'jquery.fileupload': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'account/account', 'jquery.fileupload', 'jquery.ui.widget', 'amazeui'], function($, events, g, RelatedObjectLookups, account, fileupload) {
    var descURL =  '/api/fdmanage/goods/updateSetFreightFeeDesc';
    $(function() {
        var message = $('#message');

       $('.save').on('click',function(){

        var desc = $('#desc').val();
        $.post(descURL,{desc:desc},function(data){
            if(data.status == 'success'){
                message.html(g.success(data.msg));
            }else{
                message.html(g.error(data.msg));
            }
        })
       })
    });

});
