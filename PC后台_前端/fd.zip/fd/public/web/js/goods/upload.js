require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'jquery.ui.widget': 'jquery/jquery.ui.widget',
        'jquery.fileupload': 'jquery/jquery.fileupload',
        'amazeui': 'amazeui.min'

    },
    shim: {
        'jquery.validate': ['jquery'],
        'jquery.ui.widget': ['jquery'],
        'jquery.fileupload': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'account/account', 'jquery.fileupload', 'jquery.ui.widget', 'amazeui'], function($, events, g, RelatedObjectLookups, account, fileupload) {

    $(function() {
        var message = $('#message');

        $('#fileupload').fileupload({
            type: 'POST',
            url: '/api/mgms/goods/upload_goods',
            dataType: 'json',
            multipart: true,
            autoUpload: false,
            replaceFileInput: false,
            singleFileUploads: false,
            redirectParamName: false,
            redirect: false,
            add: function(e, data) {
                data.context = $('.upload-btn').text('上传').css({
                    'background-color': '#e6e6e6',
                    'color': 'inherit'
                }).click(function() {
                    data.context = $(this).text('上传中...');
                    data.submit();
                });

            },
            done: function(e, data) {
                if (data.result.status === 'success') {
                    message.html(g.success(data.result.msg));
                    data.context.text('上传完成').css({
                        'background-color': '#95c12e',
                        'color': '#fff',
                        'border': 'none'
                    });;

                } else {
                    message.html(g.error(data.result.msg));

                };

            },
            fail: function (e, data) {
              message.html(g.error(data.textStatus === 'error' ? '上传失败' : data.errorThrown));
              data.context.text('上传失败')

            }
        });

        $('.check').click(function(event) {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;
        });

        $('#upload-csv').change(function(event) {
            if ($(this)[0].files.length > 0) {
                $(this).siblings('div').children().css({
                    'background-color': '#95c12e',
                    'color': '#fff'
                });
                $(this).siblings('div').find('i').text(' 已选择文件');
            } else
                $(this).siblings('div').children().css('background-color', 'none');

        });

    });

});
