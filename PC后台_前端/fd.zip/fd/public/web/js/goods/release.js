require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min',
        'wangEditor': 'wangEditor/js/wangEditor-1.3.12.min',
        'plupload': 'wangEditor/js/plupload.full.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'amazeui', 'wangEditor', 'plupload', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {

    var addGoodsURL = '/api/fdmanage/goods/addGoods';
    var updateGoodsURL = '/api/fdmanage/goods/editGoods';
    var changeSpeStatusURL = '/api/mgms/goods/spe_status';
    var stockoutSpeStatusURL = '/api/mgms/goods/spe_stockout_status';
    var getTokenURL = '/api/fdonline/getqiniutoken';
    var uploadURL = 'http://up.qiniu.com/';

    $(function() {
        var goodsImg = $('#goods_img');
        var imgZone = $('#img-zone');
        var editor = '';
        var standard = $('.guige ul li').length - 1;
        var message = $('#message');
        var sort = 0;
        $('#choice-category').change(function() {
            var val = $(this).val();
            var valname = val.split('|')[1];
            var valid = val.split('|')[0];
            $(this).val(valid);
            $('.category-show').val(valname)
        })
        $('form').validate({
            rules: {
                category_str: {
                    required: true
                },
                goods_name: {
                    required: true
                }
            },
            messages: {
                category_id: {
                    required: '请选择商品所属分类'
                },
                goods_name: {
                    required: '请输入商品名称'
                }
            },
            errorPlacement: function(error, element) {
                message.html(g.error(error.text()));

            },
            submitHandler: function(form) {

                var formNode = $(form);
                var data = g.serialize(form);
                console.log(data);

                $.post(formNode.attr('data-id') ? updateGoodsURL : addGoodsURL, data, function(_data) {
                    if (_data.status === 'success') {
                        message.html(g.success(_data.msg));

                        g.redirect('/goods/list');

                    } else {
                        message.html(g.error(_data.msg));

                    };

                }, 'json');

                return false;

            }
        });

        $('.check').click(function(event) {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;
        });

        $('#free').click(function() {
            if (this.checked) {
                if (!($('#free-hide').is('.hide')))
                    $('#free-hide').addClass('hide');
            } else {
                if ($('#free-hide').is('.hide'))
                    $('#free-hide').removeClass('hide');
            }

        });

        $('#add-standard').click(function() {
            standard++;
            var appendNode = $('<li>', {
                id: 'standard-' + standard
            }).append($('<input>', {
                type: "text",
                name: '',
                placeholder: "输入商品规格"
            })).append($('<a>', {
                class: 'am-fr am-btn am-btn-white am-text-danger',
                id: 'del-standard',
                href: 'javascript:;',
                text: '删除'
            }));

            $(this).parent().before(appendNode);
            $(this).siblings('#add-standard-insert').trigger('click');
        });

        $('#add-standard-insert').click(function() {
            var siblings = $(this).parent().siblings();
            var tableTheadTr = $('table#table-standard thead tr');
            var tableTbodyTr = $('table#table-standard tbody tr');

            siblings.each(function(i, e) {
                var itemId = $(e).attr('id');
                var itemVal = $(e).children('input').val();
                var tableTheadTrItem = tableTheadTr.children('#' + itemId);
                var tableTbodyTrItems = tableTbodyTr;

                if (tableTheadTrItem.size() < 1) {
                    var th = $('<th>', {
                        id: itemId,
                        text: itemVal
                    });

                    tableTheadTr.children('.v0_price').before(th);

                    var tableTbodyTrItemsSize = tableTbodyTrItems.size() - 1;
                    tableTbodyTrItems.each(function(i, e) {
                        var td = $('<td>', {
                            id: itemId
                        }).append($('<input>', {
                            type: "text",
                            value: 0
                        }));

                        if (tableTbodyTrItemsSize > i) {
                            $(e).find('.v0_price').before(td);
                        }
                    });
                } else {
                    tableTheadTrItem.text(itemVal);
                }

            });

        });

        $('form').on('click', '#del-standard', function(event) {
            event.preventDefault();
            $(this).parent().remove();

            var id = $(this).parent().attr('id');

            $('table#table-standard #' + id).remove();
        });

        $('#add-table-row').click(function(event) {
            var tableTheadTh = $('table#table-standard thead tr th');
            var tableTheadThSize = tableTheadTh.size() - 1;
            var tr = $('<tr>');

            tableTheadTh.each(function(i, e) {
                if (tableTheadThSize > i) {
                    var td = $('<td>', {
                        id: $(e).attr('id')
                    }).append($('<input>', {
                        type: "text",
                        value: 0
                    }));
                } else {
                    var td = $('<td>').append($('<a>', {
                        class: 'am-btn am-btn-white am-text-danger am-btn-xs',
                        id: 'del-table-row',
                        text: '删除'
                    }));
                }

                tr.append(td);
            });

            $(this).parents('tr').before(tr);
            tr.find('input:first').val('').focus();
        });

        $('form').on('click', '#del-table-row', function(event) {
            event.preventDefault();
            $(this).parents('tr').remove();
        });

        $('form').on('click', '#guige-table-row.up', function(event) {
            event.preventDefault();
            var dom = $(this);
            var id = dom.parents('tr').attr('id');

            $.post(changeSpeStatusURL, {
                spe_id: id,
                status: 'down'
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.removeClass('up').addClass('down').text('已下架');

                } else {
                    message.html(g.error(data.msg));

                }
            });

        }).on('click', '#guige-table-row.down', function(event) {
            event.preventDefault();
            var dom = $(this);
            var id = dom.parents('tr').attr('id');

            $.post(changeSpeStatusURL, {
                spe_id: id,
                status: 'online'
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.removeClass('down').addClass('up').text('已上架');

                } else {
                    message.html(g.error(data.msg));

                }
            });

        }).on('click', '#stockout-status.up', function(event) {
            event.preventDefault();
            var dom = $(this);
            var id = dom.parents('tr').attr('id');

            $.post(stockoutSpeStatusURL, {
                spe_id: id,
                status: 'lack'
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.removeClass('up').addClass('down').text('缺货');

                } else {
                    message.html(g.error(data.msg));

                }
            });

        }).on('click', '#stockout-status.down', function(event) {
            event.preventDefault();
            var dom = $(this);
            var id = dom.parents('tr').attr('id');

            $.post(stockoutSpeStatusURL, {
                spe_id: id,
                status: 'enough'
            }, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    dom.removeClass('down').addClass('up').text('不缺货');

                } else {
                    message.html(g.error(data.msg));

                }
            });

        });

        $('.guige').on('change', 'input', function(event) {
            event.preventDefault();

            $('#add-standard-insert').trigger('click');

        });

        $('.am-form #img-zone').on('click', '.am-close', function(event) {
            event.preventDefault();
            $(this).parent().remove();
        });

        var editor = $('#editor').wangEditor({
            //重要：传入 uploadImgComponent 参数，值为 $uploadContainer
            uploadImgComponent: $('#uploadContainer')
        });

        g.getToken(getTokenURL, function(data) {
            events.emit('editor', data);
            events.emit('uploadGoodsImg', data);

        });

        events.on('editor', function(data) {
            var token = {
                token: data.token
            };

            //实例化一个上传对象
            var uploader = new plupload.Uploader({
                browse_button: 'btnBrowse',
                url: uploadURL,
                // flash_swf_url: 'plupload/Moxie.swf',
                // sliverlight_xap_url: 'plupload/Moxie.xap',
                multipart_params: token,
                multi_selection: false,
                filters: {
                    mime_types: [
                        //只允许上传图片文件 （注意，extensions中，逗号后面不要加空格）
                        {
                            title: "图片文件",
                            extensions: "jpg,gif,png,bmp"
                        }
                    ]
                }
            });

            //初始化
            uploader.init();

            //绑定文件添加到队列的事件
            uploader.bind('FilesAdded', function(uploader, files) {
                uploader.start();

            });

            //单个文件上传之后
            uploader.bind('FileUploaded', function(uploader, file, responseObject) {
                editor.command(event, 'insertHTML', '<img src="' + 'http://ulishop.qiniudn.com/' + JSON.parse(responseObject.response).key + '"/>');

            });

        });

        events.on('uploadGoodsImg', function(data) {
            var token = data.token;

            goodsImg.change(function() {

                for (var i = 0, len = goodsImg[0].files.length; i < len; i++) {

                    g.upload(goodsImg[0].files[i], token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                    });

                }

            });

        });

        events.on('upload', function(data, token) {
            var thumbnail = $('<div>', {
                class: 'am-u-sm-4 am-u-end'
            });

            thumbnail.append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            }));

            thumbnail.append($('<input>', {
                type: 'hidden',
                value: data.key,
                name:'imagePaths'
            }).attr('sort', ++sort));

            thumbnail.append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key,
                placeholder: '商品主图'
            }));

            imgZone.append(thumbnail);

        });

    });

});
