require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min',
        'CKEDITOR': 'ckeditor/ckeditor',
        'wangEditor': 'wangEditor/js/wangEditor-1.3.12.min',
        'plupload': 'wangEditor/js/plupload.full.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
         'amazeui' : ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'wangEditor', 'plupload'], function($, events, g) {
    var getTokenURL = '/api/fdonline/getqiniutoken';
    var uploadURL = 'http://up.qiniu.com/';
    var addGoodsURL = '/api/fdmanage/notice/addSystemNotice';
    var updateGoodsURL = '/api/fdmanage/notice/editSystemNotice';

    $(function() {
        var message = $('#message');
        var formNode = $('#article-form');
        var nowDate = new Date();

        $('#screening-date-start').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).
        on('changeDate.datepicker.amui', function(event) {

            if (event.date.valueOf() < nowDate.valueOf()) {

                message.html(g.error('结束日期你能小于今天！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });


        $('#add-groups').click(function() {
            var formData = {};
            var id = $(this).attr('data-id');
            var backurl = '/info/';
            formData = g.serialize(formNode);
            id && (formData['id'] = id);
            console.log(formData);
            $.post(id ? updateGoodsURL : addGoodsURL, formData, function(data) {
                console.log(data);
                if (data.status == 'success') {
                    console.log(data,message);
                    message.html(g.success(data.msg));
                    g.redirect(backurl);

                } else {
                    message.html(g.error(data.msg));

                }

            });

        });


    });

});
