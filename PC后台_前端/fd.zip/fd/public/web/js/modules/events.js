define(function() {
    var events,
        queue = {},
        thenQueue = {},
        self = this;

    var getKeyToArray = function(key) {
        if (!key || !(key instanceof Array || typeof key === 'string')) return false;

        typeof key === 'string' && (key = key.split(' '));

        key = key.filter(function(v) {
            return v;

        }); //过滤空项

        return key;

    };

    return function() {
        events = events || {
            // 绑定事件
            on: function(key, fn) {
                if (!key) return false;

                fn = fn || function() {};

                queue[key] ? queue[key].push(fn) : queue[key] = [fn];

            },
            // 重新注册事件
            one: function(key, fn) {
                if (!key) return false;

                fn = fn || function() {};

                return this.unbind(key) && this.on(key, fn);

            },
            // 解绑事件
            unbind: function(key) {
                if (!key) return false;

                return delete queue[key];

            },
            // 触发事件
            emit: function(key) {
                if (key) {
                    var arg = Array.prototype.slice.call(arguments),
                        key = arg.shift();

                    if (queue[key] && queue[key].length) {
                        for (var i = 0, stack = queue[key], len = stack.length; i < len; i++) {
                            if (stack[i].apply(self, arg) === false) return false;

                        };

                    };

                    return this.assign(key, arg) && this.subscribe();


                };

                return false;

            },
            // 组合事件的触发通知
            assign: function(key, arg) {
                if (queue[key]) {
                    queue[key].arg = arg;

                    for (var i in thenQueue) {
                        var nowQueue = thenQueue[i];
                        var _events = nowQueue.events;

                        nowQueue.emit = true;
                        nowQueue.arg = [];

                        for (var _i in _events) {
                            _i === key && (_events[_i] = true);

                            _events[_i] === false && (nowQueue.emit = false);

                            nowQueue.emit && nowQueue.arg.push(queue[_i].arg);

                        };


                    };

                    return true;

                };

                return false;


            },
            // 触发可触发的组合事件
            subscribe: function() {
                for (var i in thenQueue) {
                    var nowQueue = thenQueue[i];

                    if (nowQueue.emit) {
                        this.unbindthen(i);

                        for (var _i = 0, _len = nowQueue.length; _i < _len; _i++) {
                            if (nowQueue[_i].apply(self, nowQueue.arg) === false) return false;

                        };


                    };


                };



            },
            // 添加组合事件
            then: function(key, fn) {
                key = getKeyToArray(key);

                if (key) {
                    var _thenQueue = thenQueue[key];

                    _thenQueue ? _thenQueue.push(fn) : thenQueue[key] = _thenQueue = [fn]; //将新回调插入事件组合列队

                    if (!_thenQueue.events) {
                        _thenQueue.events = {};

                        for (var i = 0, len = key.length; i < len; i++) { //事件组合与事件列队映射
                            this.on(key[i]);

                            _thenQueue.events[key[i]] = false;

                        };


                    };

                    return true;

                };

                return false;

            },
            // 组合事件解绑
            unbindthen: function(key) {
                key = getKeyToArray(key);

                if (key) return delete thenQueue[key];

                return false;

            }

        };

        events.trigger = events.emit;

        return events;

    };

}());
