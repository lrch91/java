define(['jquery', 'events', 'g'], function($, events, config, g) {
    var  userInfoListUrl= '/api/mgms/member/list';
    var userInfoIdUrl = '/api/mgms/member/detial';

    var exports = {
        userInfoListUrl: function(id) {

            $.getJSON(userInfoListUrl, {
                loginName: loginName,
                mobileNumber: mobileNumber
            }, function(data) {
                if (data.status === 'success') {
                    events.emit('userInfoId', data.rows);

                } else {
                    setTimeout(function() {
                        userInfoListUrl(id);

                    }, 2000);

                };

            }, 'json');

            return false;

        },
        userInfoIdUrl: function(id) {

            $.getJSON(userInfoIdUrl, {
                id: id
            }, function(data) {
                if (data.status === 'success') {
                    events.emit('userInfoId', data.rows[0]);

                }else {
                    setTimeout(function() {
                        userInfoIdUrl(id);

                    }, 2000)
                };

            });

        }
    };

    return exports;

});