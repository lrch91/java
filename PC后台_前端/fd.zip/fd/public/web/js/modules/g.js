define(['jquery', 'events'], function($, events) {
    var loginURL = '/api/user/login',
        messagecodeURL = '/api/user/messagecode',
        updateusernameURL = '/api/user/updateusername',
        //获取七牛接口
        getqiniutokenURL = '/api/fdonline/getqiniutoken',
        uploadURL = 'http://up.qiniu.com/';



    $.ajaxSetup({
        cache: false
    });

    Date.prototype.format = function(format) {
        format = format || 'yyyy-MM-dd hh:mm:ss';

        var date = {
            'M+': this.getMonth() + 1,
            'd+': this.getDate(),
            'h+': this.getHours(),
            'm+': this.getMinutes(),
            's+': this.getSeconds(),
            'q+': Math.floor((this.getMonth() + 3) / 3),
            'S+': this.getMilliseconds()
        };

        if (/(y+)/i.test(format)) {
            format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
        };

        for (var k in date) {
            if (new RegExp("(" + k + ")").test(format)) {
                format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
            }
        };

        return format;

    };

    var validateCode = function() {
        var timeout = 0;
        var timetext = function(_dom) {
            if (--timeout) {
                _dom.text('再次发送 (' + timeout + ')');
                _dom.addClass('msge1')

                setTimeout(function() {
                    timetext(_dom);

                }, 1000);

            } else {
                _dom.text('重新获取短信验证码');
                _dom.removeClass('msge1')
            };

        };

        return function(data, fn, dom) {
            data = data || {};
            fn = fn || function() {};
            dom = dom || $('<span>');

            if (timeout) {
                dom.html('请勿频繁发送验证码');

            } else {
                $.post(messagecodeURL, data, fn, 'json');

                timeout = 60;
                timetext(dom);

            };


        }
    };

    var g = {
        login: function(data, cb) {
            data = data || {
                loginstr: '',
                password: ''
            };

            $.post(loginURL, this.serialize(data), function(_data) {
                console.log(_data);
                if (_data.status === 'success') {
                    var _events = [];
                    for (var i in _data.station) {
                        var url = _data.station[i] + 'login?callback=login&cookie=' + _data.cookievalue;

                        _events.push(i);

                        (function(i) {
                            $.getScript(url, function() {
                                events.emit(i);

                            });

                        })(i);

                    };

                    events.then(_events, function() {
                         events.trigger('login', _data);
                        cb(_data);

                    });

                } else {
                    cb(_data);

                };


            }, 'json');

        },
        toThousands: function(num) {
            return parseFloat(num || 0).toFixed(2).toString().replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');

        },
        serialize: function(form, data) {
            if ($.isPlainObject(form)) {
                data = form;

            } else {
                data = data || {};

                form instanceof $ || (form = $(form));

                $.each(form.serializeArray(), function(i, v) {
                    if (/.*\[\]/.test(v.name)) {
                        var name = v.name.replace('[]', '');

                        data[name] ? data[name].push(v.value) : data[name] = [v.value];

                    } else {
                        data[v.name] = v.value;

                    }

                });


            };

            return data;

        },
        getQiNiuToken: function(fn) {
            fn = fn || function() {};

            $.getJSON(getqiniutokenURL, function(data) {
                fn(data);

            }, 'json');

        },
        getToken: function(URL, fn) {
            fn = fn || function() {};

            $.getJSON(URL, function(data) {
                fn(data);

            }, 'json');

        },
        //普通上传
        upload: function(file, token, onreadystatechange, progress, key) {
            if (!token) return;

            onreadystatechange = onreadystatechange || function() {};
            progress = progress || function() {};

            var xhr = new XMLHttpRequest();
            var formData = new FormData();

            xhr.open('POST', uploadURL, true);

            formData.append('file', file);
            formData.append('token', token);
            key && formData.append('key', key);

            xhr.upload.addEventListener('progress', progress, false);

            xhr.onreadystatechange = onreadystatechange;

            return xhr.send(formData);

        },
        _validateCode: validateCode,
        validateCode: validateCode(),
        TemplateEngine: function(html, options) {
            var re = /<% ([^%>]+)? %>/g,
                reExp = /(^( )?(if|for|else|switch|case|break|{|}))(.*)?/g,
                code = 'var r=[];\n',
                cursor = 0;

            var add = function(line, js) {
                js ? (code += line.match(reExp) ? line + '\n' : 'r.push(' + line + ');\n') :
                    (code += line != '' ? 'r.push("' + line.replace(/"/g, '\\"') + '");\n' : '');
                return add;
            };

            while (match = re.exec(html)) {
                add(html.slice(cursor, match.index))(match[1], true);
                cursor = match.index + match[0].length;
            };

            add(html.substr(cursor, html.length - cursor));
            code += 'return r.join("");';
            return new Function(code.replace(/[\r\t\n]/g, '')).apply(options);

        },
        msg: function(msg, type) {
            msg = msg || '';
            return $('<div>', {
                class: 'admin-alert am-alert ' + (type ? 'admin-alert-' + type : ''),
                'data-am-alert': ''
            }).append($('<span>', {
                class: 'adicon-left am-fl adicon ' + (type ? 'adicon-alert-' + type : '')
            }), $('<span>', {
                class: 'adicon-right am-fr am-close adicon ' + (type ? 'adicon-alert-' + type + '-close' : '')
            }), $('<span>', {
                class: 'ad-alert-msg',
                text: msg
            }));
        },
        success: function(msg) {
            return this.msg(msg, 'success');

        },
        error: function(msg) {
            return this.msg(msg, 'error');

        },
        warning: function(msg) {
            return this.msg(msg, 'warning');

        },
        redirect: function(url,time) {
            var time = time || 2000;
            setTimeout(function() {
                window.location.href = url || '/';

            }, time);

        },
        reload: function(time) {
            var time = time || 2000;
            setTimeout(function() {
                window.location.reload();

            }, time);

        }


    };

    (function(window) {
        var onhashchange = function() {
            var hash = window.location.hash;

            events.trigger('hashchange', hash.substr(1, hash.length));

        };

        // 如果浏览器原生支持该事件,则退出
        if ('onhashchange' in window.document.body) {
            window.onhashchange = onhashchange;

            return;

        };

        var location = window.location,
            oldURL = location.href,
            oldHash = location.hash;

        // 每隔100ms检测一下location.hash是否发生变化
        setInterval(function() {
            var newURL = location.href,
                newHash = location.hash;

            // 如果hash发生了变化,且绑定了处理函数...
            if (newHash != oldHash) {
                // execute the handler
                oldURL = newURL;
                oldHash = newHash;

                onhashchange();

            };

        }, 100);

    })(window);

    window.g = window.g || g;

    return g;

});
