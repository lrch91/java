require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var delRecommendURL = '/api/mgms/recommend/delete';
    var getRecommendGoodsListURL = '/api/mgms/recommend/rec_goods_list';
    var delGoodsURL = '/api/mgms/recommend/delete_rec_goods'

    $(function() {
        var message = $('#message');

        $('form').on('click', '.open-rec-goods', function(event) {
            event.preventDefault();
            var pnode = $(this).parents('tr');
            var id = pnode.attr('data-id');
            var boolId = id && id !== '' && id !== undefined;

            if (pnode.hasClass('opened')) {
                events.emit('showGoodsList', id, pnode);
                boolId = false;
            }

            if (boolId) {
                $.post(getRecommendGoodsListURL, {
                    rec_id: id,
                    page: 1,
                    pageSize: 1000
                }, function(data) {
                    if (data.status === 'success') {
                        events.emit('getGoodsList', id, pnode, data.rows);

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            }

        }).on('click', '.close-rec-goods', function(event) {
            event.preventDefault();
            var pnode = $(this).parents('tr');
            var id = pnode.attr('data-id');

            events.emit('hideGoodsList', id, pnode);

        }).on('click', '#del-rec', function(event) {
            event.preventDefault();
            var id = $(this).parent().attr('data-id');
            var pTR = $(this).parents('tr');
            var boolId = id && id !== '' && id !== undefined;
            id = boolId ? id : '';

            if (confirm("是否确认删除？")) {
                $.post(delRecommendURL, {
                    rec_id: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        pTR.remove();

                        if ($('table .close-rec-goods').length < 1) {
                            $('table #rec-goods-count').removeClass('hide');
                            $('table #rec-goods-sort').removeClass('hide');
                            $('table #goods-name').addClass('hide');
                            $('table #goods-price').addClass('hide');
                            $('table #goods-sell').addClass('hide');

                        }

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            }

        }).on('click', '#goods-del', function(event) {
            event.preventDefault();
            var id = $(this).parents('tr').attr('data-id');
            var pTR = $(this).parents('tr');
            var boolId = id && id !== '' && id !== undefined;
            id = boolId ? id : '';

            if (confirm("是否确认删除？")) {
                $.post(delGoodsURL, {
                    rec_goods_id: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        // if (pTR.siblings('#' + pTR.attr('id')).length < 1)
                        //     events.emit('hideGoodsList', id, $("tr[data-id='" + id +"']"));

                        pTR.remove();

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            }

        });

        events.on('getGoodsList', function(rec_id, pnode, data) {
            var len = data.length;

            for (var i = len - 1; i >= 0; i--) {
                var tr = $('<tr>', {
                    id: rec_id,
                    'data-id': data[i].id
                }).append(
                    $('<td>'),
                    $('<td>', {
                        id: 'goods-del',
                        text: data[i].name
                    }),
                    $('<td>', {
                        id: 'goods-del',
                        text: data[i].price
                    }),
                    $('<td>', {
                        id: 'goods-del',
                        text: data[i].sale_volume
                    }),
                    $('<td>').append(
                        $('<a>', {
                            class: 'am-btn am-btn-white am-text-secondary am-btn-xs mg-lr-5',
                            href: '/homemanagement/goods/' + rec_id + '/' + data[i].id
                        }).append($('<span>', {
                            class: 'am-icon-pencil'
                        }).text(' 编辑')),
                        $('<a>', {
                            id: 'goods-del',
                            class: 'am-btn am-btn-white am-text-danger am-btn-xs mg-lr-5',
                            href: 'javascript:;'
                        }).append($('<span>', {
                            class: 'am-icon-ban'
                        }).text(' 删除'))
                    )

                );
                pnode.after(tr);
            };

            events.emit('showGoodsList', rec_id, pnode);

        });

        events.on('showGoodsList', function(rec_id, pnode) {
            pnode.addClass('opened');
            pnode.siblings('#' + rec_id).show();
            $('table #rec-goods-count').addClass('hide');
            $('table #rec-goods-sort').addClass('hide');
            $('table #goods-name').removeClass('hide');
            $('table #goods-price').removeClass('hide');
            $('table #goods-sell').removeClass('hide');

            pnode.find('.open-rec-goods').removeClass('open-rec-goods').addClass('close-rec-goods')
                .find('i').removeClass('am-icon-chevron-right').addClass('am-icon-chevron-down');


        });

        events.on('hideGoodsList', function(rec_id, pnode) {
            pnode.siblings('#' + rec_id).hide();

            pnode.find('a.close-rec-goods').removeClass('close-rec-goods').addClass('open-rec-goods')
                .find('i').removeClass('am-icon-chevron-down').addClass('am-icon-chevron-right');

            if ($('table .close-rec-goods').length < 1) {
                $('table #rec-goods-count').removeClass('hide');
                $('table #rec-goods-sort').removeClass('hide');
                $('table #goods-name').addClass('hide');
                $('table #goods-price').addClass('hide');
                $('table #goods-sell').addClass('hide');

            }

        });

    });

});
