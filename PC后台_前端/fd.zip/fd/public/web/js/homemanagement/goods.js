require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var delGoodsURL = '/api/mgms/recommend/delete_rec_goods';

    $(function() {
        var message = $('#message');

        $('form').on('click', '#del', function(event) {
            event.preventDefault();
            var id = $(this).parent().attr('data-id');
            var pTR = $(this).parents('tr');
            var boolId = id && id !== '' && id !== undefined;
            id = boolId ? id : '';

            if (confirm("是否确认删除？")) {
                $.post(delGoodsURL, {
                    rec_goods_id: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        pTR.remove();

                    } else {
                        message.html(g.error(data.msg));

                    }

                });
            }

        });

    });

});
