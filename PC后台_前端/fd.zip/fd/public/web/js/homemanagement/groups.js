require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'jquery.validate'], function($, events, g) {
    var addRecommendURL = '/api/mgms/recommend/add';
    var updateRecommendURL = '/api/mgms/recommend/update';
    var addTagURL = '/api/mgms/recommend/add_tags';
    var updateTagURL = '/api/mgms/recommend/update_tags';
    var delTagURL = '/api/mgms/recommend/delete_tags';
    var getTokenURL = '/api/mgms/goods/get_token';
    var uploadURL = 'http://up.qiniu.com/';

    $(function() {
        var message = $('#message');
        var groupsImg = $('#groups_img');
        var imgZone = $('#img-zone');

        jQuery.validator.addMethod("isIntGteZero", function(value, element) {
            vInt = parseInt(value);
            return this.optional(element) || (/^[0-9]*.[0]*$/.test(value) && vInt >= 0);
        }, "请输入整数且必须大于或等于0");

        jQuery.validator.addMethod("isColor", function(value, element) {
            return this.optional(element) || /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value);
        }, "请输入符合规范的颜色，如#abc或者#123456");

        $('#groups-form').validate({
            rules: {
                title: {
                    required: true
                },
                right_weight: {
                    required: true,
                    number: true,
                    isIntGteZero: true
                },
                rec_color: {
                    required: true,
                    isColor: true
                }
            },
            messages: {
                title: {
                    required: '请输入分组名称'
                },
                right_weight: {
                    required: '请输入分组排序',
                    number: '请输入大于或等于0的整数'
                },
                rec_color: {
                    required: '请输入分组颜色'
                }
            },
            errorPlacement: function(error, element) {
                message.html(g.error(error.text()));

            },
            success: function(str) {
                message.empty();
                if (str[0].htmlFor === 'rec_color') {
                    var input = $('input[name="rec_color"]');
                    $('#rec_color').css('background-color', input.val());
                }

            },
            submitHandler: function(form) {
                var formData = g.serialize($(form));
                var id = formData['id'];
                var boolId = id && id !== '' && id !== undefined;

                $.post(boolId ? updateRecommendURL : addRecommendURL, formData, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        if (!boolId) {
                            $(form).prepend($('<input>', {
                                type: 'hidden',
                                name: 'id',
                                value: data.rec_id
                            }));
                            $('#tags-table').removeClass('am-hide').addClass('am-block');
                        }

                    } else {
                        message.html(g.error(data.msg));

                    }

                });

            }
        });

        $('#add-table-row').click(function() {
            var pnode = $(this).parents('tr');
            var tr = $('<tr>', {
                id: 'tag-row'
            }).append(
                $('<td>').append(
                    $('<span>').css('display', 'none'),
                    $('<input>', {
                        type: 'text',
                        value: '名称'
                    })),
                $('<td>').append(
                    $('<span>').css('display', 'none'),
                    $('<input>', {
                        type: 'text',
                        value: '链接'
                    })),
                $('<td>').append($('<a>', {
                        id: 'edit-table-row',
                        class: 'am-btn am-btn-white am-text-secondary am-btn-xs',
                        href: 'javascript:;',
                        text: '编辑'
                    }).css('display', 'none'),
                    $('<a>', {
                        id: 'save-table-row',
                        class: 'am-btn am-btn-white am-text-secondary am-btn-xs',
                        href: 'javascript:;',
                        text: '保存'
                    }),
                    $('<a>', {
                        id: 'del-table-row',
                        class: 'am-btn am-btn-white am-text-danger am-btn-xs mg-lr-5',
                        href: 'javascript:;',
                        text: '删除'
                    })
                ));

            pnode.before(tr)

        });

        $('table').on('click', '#edit-table-row', function(event) {
            event.preventDefault();
            var pnode = $(this).parents('tr');

            pnode.find('span').each(function(i, e) {
                var node = $(e);
                var val = node.attr('data-value');

                node.before($('<input>', {
                    type: 'text',
                    value: val
                }));

                node.hide();

            });

            $(this).before($('<a>', {
                id: 'save-table-row',
                class: 'am-btn am-btn-white am-text-secondary am-btn-xs',
                href: 'javascript:;',
                text: '保存'
            })).hide();

        }).on('click', '#save-table-row', function(event) {
            event.preventDefault();
            var pnode = $(this).parents('tr');
            var id = pnode.attr('data-id');
            var boolId = id && id !== '' && id !== undefined;
            var put = {};

            pnode.find('input').each(function(i, e) {
                var node = $(e);
                var span = node.siblings('span');
                var val = node.val();

                span.attr('data-value', val).text(val);
                put[i ? 'link' : 'tag_name'] = val;

                span.show();
                node.remove();

            });

            if (!boolId)
                put['recommendation_id'] = $(this).parents('form').attr('data-id');
            else
                put['id'] = id;

            $.post(boolId ? updateTagURL : addTagURL, put, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    if (!boolId) {
                        pnode.attr('data-id', data.tag_id);
                    }

                } else {
                    message.html(g.error(data.msg));

                }

            });

            $(this).siblings().show();
            $(this).remove();

        }).on('click', '#del-table-row', function(event) {
            event.preventDefault();
            var pnode = $(this).parents('tr');
            var id = pnode.attr('data-id');
            var boolId = id && id !== '' && id !== undefined;

            if (boolId) {
                $.post(delTagURL, {
                    tags_id: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));

                        pnode.remove();

                    } else {
                        message.html(g.error(data.msg));

                    }

                });

            } else {
                pnode.remove();

            }

        });

        $('.am-form #img-zone').on('click', '.am-close', function(event) {
            event.preventDefault();
            $(this).parent().remove();
        });

        g.getToken(getTokenURL, function(data) {
            events.emit('uploadImg', data);

        });

        events.on('uploadImg', function(data) {
            var token = data.token;

            groupsImg.change(function() {
                g.upload(groupsImg[0].files[0], token, function(response) {
                    this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                });

            });

        });

        events.on('upload', function(data, token) {
            var thumbnail = $('<div>', {
                class: 'am-u-sm-2 am-u-sm-offset-1 am-u-end'
            });

            thumbnail.append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            }));

            thumbnail.append($('<input>', {
                type: 'hidden',
                name: 'icon_path',
                value: data.key
            }));

            thumbnail.append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key,
                placeholder: '商品主图'
            }));

            imgZone.empty().append(thumbnail);

        });

        // $('#add-recommend').click(function() {
        //     var inputs = $('#input-hidden');
        //     var formData = g.serialize($('#groups-form'));
        //     var id = $(this).attr('data-id');
        //     var boolId = id && id !== '' && id !== undefined;

        //     if (boolId)
        //         formData['id'] = id;

        //     inputs.empty();
        //     $('table tbody tr#tag-row').each(function(i, e) {
        //         var arr = [];

        //         $(e).find('input').each(function(index, el) {
        //             arr.push($(el).val())

        //         });

        //         inputs.append($('<input>', {
        //             type: 'hidden',
        //             name: 'tags[]',
        //             value: arr.join(',')
        //         }));

        //     });

        //     return false;


        //     $.post(boolId ? updateRecommendURL : addRecommendURL, formData, function(data) {
        //         if (data.status === 'success') {
        //             message.html(g.success(data.msg));

        //         } else {
        //             message.html(g.error(data.msg));

        //         }

        //     });

        // });

    });

});
