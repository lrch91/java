require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var addGoodsURL = '/api/mgms/recommend/add_rec_goods';
    var updateGoodsURL = '/api/mgms/recommend/update_rec_goods';
    var getTokenURL = '/api/mgms/common/get_token';

    $(function() {
        var message = $('#message');

        $('#add-goods').click(function() {
            var formNode = $('#goods-form');
            var formData = g.serialize(formNode);
            var id = $(this).attr('data-id');
            var boolId = id && id !== '' && id !== undefined;
            id = boolId ? id : '';

            if (boolId)
                formData['id'] = id;

            $.post(boolId ? updateGoodsURL : addGoodsURL, formData, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                } else {
                    message.html(g.error(data.msg));

                }

            });

        });

        $('form #image-zone').on('click', '.am-close', function(event) {
            event.preventDefault();

            $(this).parents('#image-zone').empty();
        });

        g.getToken(getTokenURL, function(data) {
            events.emit('getqiniutoken', data);

        });

        events.on('getqiniutoken', function(data) {
            var token = data.token;

            $('input#image').change(function() {
                var file = $(this)[0].files[0];

                if (file && file !== undefined) {
                    g.upload(file, token, function(response) {
                        this.readyState == 4 && this.status == 200 && this.responseText != '' && events.emit('upload', JSON.parse(this.responseText), token);

                    });

                }

            });

        });

        events.on('upload', function(data, token) {
            var zone = $('#image-zone');

            zone.empty();

            zone.append($('<a>', {
                class: 'am-close am-icon-close',
                href: 'javascript:;'
            })).append($('<input>', {
                type: 'hidden',
                name: 'image_path',
                value: data.key
            })).append($('<img>', {
                class: 'am-thumbnail',
                src: 'http://ulishop.qiniudn.com/' + data.key
            }));

        });

    });

});
