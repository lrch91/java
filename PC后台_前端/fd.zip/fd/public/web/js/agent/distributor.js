require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var delDistributorURL = '/api/mgms/agent/delDistributor';

    $(function() {
        var startDate = '',
            endDate = '',
            message = $('#message');

        $('table').on('click', '#distris-del', function() {
            var $this = $(this);
            var id = $this.parents('tr').attr('data-id');

            if (id && confirm('确定删除该分销商？')) {
                $.post(delDistributorURL, {
                    distributorId: id
                }, function(data) {
                    if (data.status === 'success') {
                        message.html(g.success(data.msg));
                        $this.parents('tr').remove();

                    } else {
                        message.html(g.error(data.msg));

                    };

                });

            }

        });

        $('#screening-date-start').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).on('changeDate.datepicker.amui', function(event) {
            startDate = new Date(event.date);

            if (endDate != '' && (event.date.valueOf() > endDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });

        $('#screening-date-end').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).on('changeDate.datepicker.amui', function(event) {
            endDate = new Date(event.date);

            if (startDate != '' && (event.date.valueOf() < startDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });


    });

});
