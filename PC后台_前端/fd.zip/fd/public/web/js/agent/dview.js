require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'amazeui', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {
    var addDistributorURL = '/api/mgms/agent/addDistributor';

    $(function() {
        var message = $('#message');

        $('#lookup_id_user').click(function() {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;

        });

        $('#lookup_id_duser').click(function() {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;

        });

        $('#from').validate({
            rules: {
                distributorName: {
                    required: true
                },
                agentName: {
                    required: true
                }
            },
            messages: {
                distributorName: {
                    required: '请选择分销商'
                },
                agentName: {
                    required: '请选择代理商'
                }
            },
            errorPlacement: function(error, element) {
                message.html(g.error(error.text()));

            },
            submitHandler: function(form) {
                var data = g.serialize(form);

                $.post(addDistributorURL, data, function(_data) {
                    if (_data.status === 'success') {
                        message.html(g.success(_data.msg));

                        g.redirect('/agent/distributor/');

                    } else {
                        message.html(g.error(_data.msg));

                    };

                }, 'json');

                return false;

            }

        });


    });

});
