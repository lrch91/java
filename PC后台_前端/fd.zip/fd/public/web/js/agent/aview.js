require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'amazeui', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {
    var addAgentURL = '/api/mgms/agent/addAgent';
    var editAgentURL = '/api/mgms/agent/editAgent';

    $(function() {
        var message = $('#message');

        $('#lookup_id_user').click(function() {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;

        });

        jQuery.validator.addMethod("isNumber", function(value, element) {
            return this.optional(element) || /^[-\+]?\d+$/.test(value) || /^[-\+]?\d+(\.\d+)?$/.test(value);
        }, "请输入大于0小于1的数值");

        jQuery.validator.addMethod("isIntGtZero", function(value, element) {
            value = parseFloat(value);
            return this.optional(element) || value > 0;
        }, "必须大于0");

        jQuery.validator.addMethod("isIntLtOne", function(value, element) {
            value = parseFloat(value);
            return this.optional(element) || value < 1;
        }, "必须小于1");

        $('#from').validate({
            rules: {
                loginName: {
                    required: true
                },
                areaTitle: {
                    required: true
                },
                commissionRate: {
                    required: true,
                    isNumber: true,
                    isIntGtZero: true,
                    isIntLtOne: true
                },
                status: {
                    required: true
                }
            },
            messages: {
                loginName: {
                    required: '请选择代理商'
                },
                areaTitle: {
                    required: '请输入佣金比例'
                },
                commissionRate: {
                    required: '请代理地区'
                },
                status: {
                    required: '请选择状态'
                }
            },
            errorPlacement: function(error, element) {
                message.html(g.error(error.text()));

            },
            submitHandler: function(form) {
                var data = g.serialize(form);

                $.post(data['userId'] ? editAgentURL : addAgentURL, data, function(_data) {
                    if (_data.status === 'success') {
                        message.html(g.success(_data.msg));

                        g.redirect('/agent/');

                    } else {
                        message.html(g.error(_data.msg));

                    };

                }, 'json');

                return false;

            }

        });

    });

});
