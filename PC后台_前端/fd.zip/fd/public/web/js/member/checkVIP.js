require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {
    //var unlockURL = '/api/mgms/merchant/unlockMerchant';
    //var lockURL = '/api/mgms/merchant/lockMerchant';
    var passURL = '/api/fdmanage/user/passLevelRequest'; //封号
    var unPassURL = '/api/fdmanage/user/rejectLevelRequest'; //解封
    $(function() {
        var startDate = '',
            endDate = '',
            message = $('#message');

        /*
         **删除会员
         */
        $('.pass-vip').on('click', function() {
            var level =  parseInt($(this).parents('tr').attr('data-level'));
            var id = $(this).parents('tr').attr('data-id');
            if(!level){
                $('#my-confirm2').find('.am-modal-bd').html('确定要将该用户移除会员吗')
            }
            $('#my-confirm2').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    $.post(passURL,{requestId:id},function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                   // alert('算求，不弄了');
                }
            })

        });

        $('.unpass-vip').on('click', function() {
            var id = $(this).parents('tr').attr('data-id');
            var level =  parseInt($(this).parents('tr').attr('data-level'));
            if(!level){
                $('#my-confirm').find('.am-modal-bd').html('确定拒绝将该用户设置为非会员吗')
            }
            $('#my-confirm').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    $.post(unPassURL,{requestId:id},function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    
                }
            })

        });
    })
});
