require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g','amazeui'], function($, events, g) {
    var addMemberClassURL ='/api/fdmanage/user/editUserGrade';
    var removeMemberClassURL = '/api/fdmanage/user/delUserGrade';
    $(function(){
        var message = $('#message');
        //添加
        $('.add-level').on('click',function(){
            var allLevelLength = $('.allLevelLength').val();
            $('#level-form').attr('data-level',allLevelLength);
            $('#modal-edit').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    var put = g.serialize($('#level-form'));
                    put.level = $('#level-form').attr('data-level');
                    $.post(addMemberClassURL,put,function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                }
            })
        })
        //编辑
        $('.admin-cate-edit').on('click',function(){
            $('#modal-edit').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    var put = g.serialize($('#level-form'));
                    put.ID = $('#level-form').attr('data-id');
                    put.level = $('#level-form').attr('data-level');
                    $.post(addMemberClassURL,put,function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                        $('#level-form').find('.level-up').remove();
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    $('#level-form').find('.level-up').remove();
                }
            })
        })
        //delete
        $('.admin-cate-del').on('click',function(){
            var level = $(this).attr('data-level');
            $('#my-confirm').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    $.post(removeMemberClassURL,{level:level},function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                        $('#level-form').find('.level-up').remove();
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    //alert('算求，不弄了');
                }
            })
        })



        //-----------------------------------------

        //---------
        //
        $('.admin-cate-edit').on('click',function(){
            var arr = $(this).find('input').val().split(',');
            var form = $('#level-form');
            form.attr('data-id',arr[0]);
            form.attr('data-level',arr[1]);
            form.find('#level-score').val(arr[2]);
        })
    })
});
