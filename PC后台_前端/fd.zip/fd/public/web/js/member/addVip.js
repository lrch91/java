require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'amazeui', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {
    var requestMemberLevelURL = '/api/fdmanage/user/requestMemberLevel';
    $(function() {
        var message = $('#message');
        $('#lookup_id_user').click(function() {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;

        });
        $('#add-supplier').on('click', function() {
            var put = g.serialize($('#from'));
            $.post(requestMemberLevelURL, put, function(data) {
                if (data.status == 'success') {
                    message.html(g.success(data.msg));
                    g.redirect('/member/');
                } else {
                    message.html(g.error(data.msg));
                }
            })
            return false;
        })
    })
});
