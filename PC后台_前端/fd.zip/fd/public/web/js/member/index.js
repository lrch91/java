require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {
    //var unlockURL = '/api/mgms/merchant/unlockMerchant';
    //var lockURL = '/api/mgms/merchant/lockMerchant';
    var lockURL = '/api/fdmanage/user/lockUser'; //封号
    var unlockURL = '/api/fdmanage/user/unlockUser'; //解封
    var canceVIPURL = '/api/fdmanage/user/requestMemberOut';
    $(function() {
        var startDate = '',
            endDate = '',
            message = $('#message');
        var changOprt = function(id, type, dom) {
            var $status = dom.parents('td').siblings('.status');
            console.log(id);
            $.post(type ? lockURL : unlockURL, {
                userId: id
            }, function(data) {
                if (data.status === 'success') {
                    //操作成功
                    if (type) {
                        $status.html('封号');
                        dom.removeClass('lock am-text-danger').addClass('unlock am-text-success').html('<span class="am-icon-unlock"></span> 解封');


                    } else {
                        $status.html('正常');
                        dom.removeClass('unlock am-text-success').addClass('lock am-text-danger').html('<span class="am-icon-lock"></span> 封号');

                    };

                } else {
                    alert(data.msg);

                };

            });

        };

        // 封号 解封
        $('table').on('click', '.lock', function() {
            var $this = $(this);

            var id = $this.attr('data-id');

            changOprt(id, true, $this);


        }).on('click', '.unlock', function() {
            var $this = $(this);

            var id = $this.attr('data-id');

            changOprt(id, false, $this);

        })
        $('#screening-date-start').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).on('changeDate.datepicker.amui', function(event) {
            startDate = new Date(event.date);

            if (endDate != '' && (event.date.valueOf() > endDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });

        $('#screening-date-end').datepicker({
            language: 'zh-CN',
            format: 'yyyy-mm-dd',
            pickerPosition: 'bottom-left'
        }).on('changeDate.datepicker.amui', function(event) {
            endDate = new Date(event.date);

            if (startDate != '' && (event.date.valueOf() < startDate.valueOf())) {

                message.html(g.error('开始日期应小于结束日期！')).show();

            } else {
                message.hide();
                $(this).find('input').val($(this).data('date'));

            }

            $(this).datepicker('close');

        });

        /*
         **删除会员
         */
        $('.cancel-vip').on('click', function() {
            var id = $(this).parents('tr').attr('data-id');
            $('#my-confirm').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    $.post(canceVIPURL,{userId:id},function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    //alert('算求，不弄了');
                }
            })

        });
    })
});
