require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'amazeui', 'qrcode.min'], function($, events, g) {
    var requestMemberLevelURL = '/api/fdmanage/user/requestMemberLevel';
    $(function() {
        var message = $('#message');
        var phone = $('.phone-input').val();
        var qrcode = new QRCode(document.getElementById("qrcode"), {
            width: 100,
            height: 100
        });
        if (phone) {
            qrcode.makeCode(phone);
        }
    })
});
