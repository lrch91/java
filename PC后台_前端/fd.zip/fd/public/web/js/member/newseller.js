require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'RelatedObjectLookups', 'amazeui', 'jquery.validate'], function($, events, g, RelatedObjectLookups) {
    var addSupplierURL = '/api/mgms/merchant/addMerchant';

    $(function() {
        var message = $('#message');

        $('#from').validate({
            rules: {
                loginName: {
                    required: true
                },
                status: {
                    required: true
                }
            },
            messages: {
                loginName: {
                    required: '请选择货源商'
                },
                status: {
                    required: '请选择状态'
                }
            },
            errorPlacement: function(error, element) {
                message.html(g.error(error.text()));

            },
            submitHandler: function(form) {
                var data = g.serialize(form);
                data.status = 'normal';
                $.post(addSupplierURL, data, function(_data) {
                    if (_data.status === 'success') {
                        message.html(g.success(_data.msg));

                        g.redirect('/member/seller/');

                    } else {
                        message.html(g.error(_data.msg));

                    };

                }, 'json');

                return false;

            }

        });

        $('#lookup_id_user').click(function() {
            RelatedObjectLookups.showRelatedObjectLookupPopup(this);

            return false;

        });

        // $('#add-supplier').click(function() {

        //     $.post(addSupplierURL, g.serialize($('#from')), function(data) {
        //         if (data.status === 'success') {
        //             message.html(g.success(data.msg));

        //             g.redirect('/supplier/');

        //         } else {
        //             message.html(g.error(data.msg));

        //         }

        //     });

        // });

    });

});
