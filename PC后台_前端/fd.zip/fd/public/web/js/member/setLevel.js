require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery'],
        'amazeui': ['jquery']
    }
});

require(['jquery', 'events', 'g','amazeui'], function($, events, g) {
    var addMemberClassURL ='/api/fdmanage/user/editMemberClass';
    var removeMemberClassURL = '/api/fdmanage/user/delMemberClass';
    $(function(){
        var message = $('#message');
        //添加
        $('.add-level').on('click',function(){
            $('#modal-edit').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    var put = g.serialize($('#level-form'));
                    $.post(addMemberClassURL,put,function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    $('#level-form').attr('data-id','');
                }
            })
        })
        //编辑
        $('.admin-cate-edit').on('click',function(){
            $('#modal-edit').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    var put = g.serialize($('#level-form'));
                    put.ID = $('#level-form').attr('data-id');
                    $.post(addMemberClassURL,put,function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    $('#level-form').attr('data-id','');
                }
            })
        })
        //delete
        $('.admin-cate-del').on('click',function(){
            var level = $(this).attr('data-level');
            $('#my-confirm').modal({
                relatedTarget: this,
                onConfirm: function(options) {
                    $.post(removeMemberClassURL,{level:level},function(data){
                        if(data.status=='success'){
                            message.html(g.success(data.msg));
                            g.reload()
                        }else{
                            message.html(g.error(data.msg));
                        }
                        $('#level-form').find('.level-up').remove();
                    })
                },
                // closeOnConfirm: false,
                onCancel: function() {
                    //alert('算求，不弄了');
                }
            })
        })



        //-----------------------------------------
        $('#level-name').on('change',function(){
            $('#level-name-show').html($(this).val());
        })
        $('#level-color').on('change',function(){
            $('#level-name-show').css('color',$(this).val());
        })
        $('#level-score').on('change',function(){
            $('#level-score-show').html($(this).val());
        })

        //---------
        //
        $('.admin-cate-edit').on('click',function(){
            var arr = $(this).find('input').val().split(',');
            var form = $('#level-form');
            form.attr('data-id',arr[0]);
            form.find('#level-name').val(arr[1]);
            form.find('#level-number').val(arr[2]);
            form.find('#level-color').val(arr[3]);
            form.find('#level-score').val(arr[4]);
            $('#level-name-show').html(arr[1]).css('color',arr[3]);
            $('#level-score-show').html(arr[4]);
        })
    })
});
