require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});

require(['jquery', 'events', 'g', 'account/account', 'amazeui'], function($, events, g, account) {
    var updateMemberLevelURL = '/api/mgms/member/updateMemberClass';
    var updateLoginNameURL = '/api/mgms/member/updateMemberLoginName';

    $(function() {
        var message = $('#message');

        $('.updateName').click(function() {
            var $this = $(this);
            var pr = $this.parent();

            pr.hide();
            pr.siblings().show();
            pr.siblings().find('input').val($this.attr('data-name'));
        });

        $('.cancleName').click(function() {
            var $this = $(this);
            var pr = $this.parent();

            pr.hide();
            pr.siblings().show();
        });

        $('.saveName').click(function() {
            var $this = $(this);
            var pr = $this.parent();
            var id = $(this).attr('data-id');
            var name = $(this).siblings('input').val();
            var put = {};

            // if (id && id !== '')
            //     put.id = id;
            // else
            //     return false;

            // if (name && name !== '') {
            //     if ($('.updateName').attr('data-name') === name) {
            //         message.html(g.success('账户名相同，无需修改'));
            //         $('.cancleName').trigger('click');
            //         return false;
            //     }

            //     put.loginName = name;
            // } else {
            //     message.html(g.error('帐户名为空'));
            //     return false;
            // }
            put.id = id;put.loginName = name;

            $.post(updateLoginNameURL, put, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));
                    $('#loginName').text(put.loginName);
                    $('.updateName').attr('data-name', put.loginName);
                    $('.cancleName').trigger('click');

                } else {
                    message.html(g.error(data.msg));

                };

            });

        });

        $('#save').click(function() {
            var id = $(this).attr('data-id');
            var put = g.serialize($('form'));

            if (id && id !== '')
                put.id = id;
            else
                return false;

            $.post(updateMemberLevelURL, put, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                    setTimeout(function() {
                        g.redirect('/account/');
                    }, 2000);

                } else {
                    message.html(g.error(data.msg));

                };

            });

        });

    });
    // var id = $.search().get('id'),
    // userInfoIdUrl = function() {
    //         account.userInfoIdUrl(id);

    //     };


    // var userInfoIdUrl = function(id) {
    //     console.log(id);
    //     $.getJSON(userInfodetial, {
    //             id: id
    //         }, function(data) {
    //             if (data.status === 'success') {
    //                 events.emit('userInfoId', data.rows[0]);

    //             } else {
    //                 setTimeout(function() {
    //                     userInfoIdUrl(id);

    //                 }, 2000);

    //             };


    //         });
    // };


    // events.on('userInfoId', function(data) {
    //     $('#userName').text(data.loginName);
    //     $('#userId').text(data);
    //     $('#userDate').text(data);
    //     $('#userCp').text(data);
    //     $('#userIP').text(data);
    //     $('#niCheng').text(data);
    //     $('#name').text(data);
    //     $('#card').text(data);
    //     $('#phone').text(data);
    //     $('#qq').text(data);
    //     $('#email').text(data);
    //     $('#sex').text(data);
    //     $('#birthday').text(data);
    //     $('#xingzuo').text(data);
    //     $('#birth').text(data);
    //     $('#address').text(data);
    // });

    // // 初始化页面
    // $(userInfoIdUrl);

});
