require.config({
    baseUrl: '/web/js/modules',
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.validate': 'jquery/jquery.validate.min',
        'amazeui': 'amazeui.min'
    },
    shim: {
        'jquery.validate': ['jquery']
    }
});


require(['jquery', 'events', 'g', 'amazeui'], function($, events, g) {
    var lockURL = '/api/mgms/member/lock', //封号
        unlockURL = '/api/mgms/member/unlock', //解封
        resetURL = '/api/mgms/member/resetMemberPWD';

    $(function() {
        var message = $('#message');
        var changOprt = function(id, type, dom) {
            var $status = dom.parents('td').siblings('.status');

            $.post(type ? lockURL : unlockURL, {
                id: id
            }, function(data) {
                if (data.status === 'success') {
                    //操作成功
                    if (type) {
                        $status.html('封号');
                        dom.removeClass('lock am-text-danger').addClass('unlock am-text-success').html('<span class="am-icon-unlock"></span> 解封');


                    } else {
                        $status.html('正常');
                        dom.removeClass('unlock am-text-success').addClass('lock am-text-danger').html('<span class="am-icon-lock"></span> 封号');

                    };

                } else {
                    alert(data.msg);

                };

            });

        };

        // 封号 解封
        $('.am-btn-toolbar').on('click', '.lock', function() {
            var $this = $(this);

            var id = $this.attr('data-id');

            changOprt(id, true, $this);


        }).on('click', '.unlock', function() {
            var $this = $(this);

            var id = $this.attr('data-id');

            changOprt(id, false, $this);

        }).on('click', '.reset', function(event) {
            event.preventDefault();
            var $this = $(this);

            var id = $this.attr('data-id');

            confirm('确认重置该用户密码吗(重置会员密码为123456)？') && $.post(resetURL, {id: id}, function(data) {
                if (data.status === 'success') {
                    message.html(g.success(data.msg));

                } else {
                    message.html(g.error(data.msg));

                };

            });

        });

    });

});
