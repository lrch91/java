var path = require('path');
var url = require('url');

var config = require('./config');

// 引入gulp
var gulp = require('gulp');

// 引入gulp组件（插件）
var amdOptimize = require('amd-optimize');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');

var less = require('gulp-less');
var autoprefixer = require('gulp-autoprefixer');
var minifycss = require('gulp-minify-css');

var revjade = require('gulp-asset-rev-jade');

var rev = require('gulp-rev');

var clean = require('gulp-rimraf');

var host = config.staticstore;

var _public = path.join(__dirname, 'public');
var built = path.join(__dirname, 'built');
var temp = path.join(__dirname, 'temp');

var templates = path.join(__dirname, 'templates');

var opt = {
    baseUrl: path.join(_public, 'web/js/modules'),
    paths: {
        'jquery': 'jquery/jquery-1.11.2.min',
        'jquery.sloadimg': 'jquery/jquery.sloadimg',
        'jquery.validate': 'jquery/jquery.validate.min',
        'jquery.imgareaselect': 'jquery/jquery.imgareaselect.min',
        'jquery.ui.widget': 'jquery/jquery.ui.widget',
        'jquery.fileupload': 'jquery/jquery.fileupload',
        'amazeui': 'amazeui.min',
        'wangEditor': 'wangEditor/js/wangEditor-1.3.12.min',
        'plupload': 'wangEditor/js/plupload.full.min'
    },
    shim: {
        'jquery.sloadimg': ['jquery'],
        'jquery.validate': ['jquery'],
        'jquery.imgareaselect': ['jquery']
    }
};

var revconf = function(root) {
    return {
        root: root || '',
        host: host,
        hashlen: 10,
        connecter: '-'
    };

};

var task = function(src, dest) {
    return gulp.src(src)
        .pipe(less())
        .pipe(revjade(revconf(_public)))
        .pipe(autoprefixer({
            browsers: ['last 2 versions'],
            cascade: false
        }))
        .pipe(minifycss())
        .pipe(gulp.dest(dest));

};



// 移动端静态images文件处理
gulp.task('web:images', function(cb) {
    return gulp.src(path.join(_public, 'web/images/**/*'))
        .pipe(gulp.dest(path.join(temp, 'web/images')));

});

// 移动端静态fonts文件处理
gulp.task('web:fonts', function(cb) {
    return gulp.src(path.join(_public, 'web/fonts/**/*'))
        .pipe(gulp.dest(path.join(temp, 'web/fonts')));

});



// 移动端静态css文件处理
gulp.task('web:css:account:index', function(cb) {
    return task(path.join(_public, 'web/css/account/index.less'), path.join(temp, 'web/css/account'));

});

gulp.task('web:css:account:member', function(cb) {
    return task(path.join(_public, 'web/css/account/member.less'), path.join(temp, 'web/css/account'));

});

gulp.task('web:css:account:view', function(cb) {
    return task(path.join(_public, 'web/css/account/view.less'), path.join(temp, 'web/css/account'));

});

gulp.task('web:css:admin:add', function(cb) {
    return task(path.join(_public, 'web/css/admin/add.less'), path.join(temp, 'web/css/admin'));

});

gulp.task('web:css:admin:choice-authority', function(cb) {
    return task(path.join(_public, 'web/css/admin/choice-authority.less'), path.join(temp, 'web/css/admin'));

});

gulp.task('web:css:admin:choice', function(cb) {
    return task(path.join(_public, 'web/css/admin/choice.less'), path.join(temp, 'web/css/admin'));

});

gulp.task('web:css:admin:edit', function(cb) {
    return task(path.join(_public, 'web/css/admin/edit.less'), path.join(temp, 'web/css/admin'));

});

gulp.task('web:css:admin:index', function(cb) {
    return task(path.join(_public, 'web/css/admin/index.less'), path.join(temp, 'web/css/admin'));

});

gulp.task('web:css:admin:node', function(cb) {
    return task(path.join(_public, 'web/css/admin/node.less'), path.join(temp, 'web/css/admin'));

});

gulp.task('web:css:home:index', function(cb) {
    return task(path.join(_public, 'web/css/home/index.less'), path.join(temp, 'web/css/home'));

});

gulp.task('web:css:log:handle', function(cb) {
    return task(path.join(_public, 'web/css/log/handle.less'), path.join(temp, 'web/css/log'));

});

gulp.task('web:css:log:index', function(cb) {
    return task(path.join(_public, 'web/css/log/index.less'), path.join(temp, 'web/css/log'));

});

gulp.task('web:css:permissions:add', function(cb) {
    return task(path.join(_public, 'web/css/permissions/add.less'), path.join(temp, 'web/css/permissions'));

});

gulp.task('web:css:permissions:edit', function(cb) {
    return task(path.join(_public, 'web/css/permissions/edit.less'), path.join(temp, 'web/css/permissions'));

});

gulp.task('web:css:permissions:index', function(cb) {
    return task(path.join(_public, 'web/css/permissions/index.less'), path.join(temp, 'web/css/permissions'));

});

gulp.task('web:css:finance:cash', function(cb) {
    return task(path.join(_public, 'web/css/finance/cash.less'), path.join(temp, 'web/css/finance'));

});

gulp.task('web:css:finance:recharge', function(cb) {
    return task(path.join(_public, 'web/css/finance/recharge.less'), path.join(temp, 'web/css/finance'));

});

gulp.task('web:css:finance:transaction', function(cb) {
    return task(path.join(_public, 'web/css/finance/transaction.less'), path.join(temp, 'web/css/finance'));

});

gulp.task('web:css:goods:category', function(cb) {
    return task(path.join(_public, 'web/css/goods/category.less'), path.join(temp, 'web/css/goods'));

});

gulp.task('web:css:goods:choice-category', function(cb) {
    return task(path.join(_public, 'web/css/goods/choice-category.less'), path.join(temp, 'web/css/goods'));

});

gulp.task('web:css:goods:list', function(cb) {
    return task(path.join(_public, 'web/css/goods/list.less'), path.join(temp, 'web/css/goods'));

});

gulp.task('web:css:goods:recycle', function(cb) {
    return task(path.join(_public, 'web/css/goods/recycle.less'), path.join(temp, 'web/css/goods'));

});

gulp.task('web:css:goods:release', function(cb) {
    return task(path.join(_public, 'web/css/goods/release.less'), path.join(temp, 'web/css/goods'));

});
gulp.task('web:css:goods:upload', function(cb) {
    return task(path.join(_public, 'web/css/goods/upload.less'), path.join(temp, 'web/css/goods'));

});

gulp.task('web:css:homemanagement:goods', function(cb) {
    return task(path.join(_public, 'web/css/homemanagement/goods.less'), path.join(temp, 'web/css/homemanagement'));

});

gulp.task('web:css:homemanagement:goodsview', function(cb) {
    return task(path.join(_public, 'web/css/homemanagement/goodsview.less'), path.join(temp, 'web/css/homemanagement'));

});

gulp.task('web:css:homemanagement:groups', function(cb) {
    return task(path.join(_public, 'web/css/homemanagement/groups.less'), path.join(temp, 'web/css/homemanagement'));

});

gulp.task('web:css:homemanagement:index', function(cb) {
    return task(path.join(_public, 'web/css/homemanagement/index.less'), path.join(temp, 'web/css/homemanagement'));

});

gulp.task('web:css:logistics:index', function(cb) {
    return task(path.join(_public, 'web/css/logistics/index.less'), path.join(temp, 'web/css/logistics'));

});

gulp.task('web:css:logistics:view', function(cb) {
    return task(path.join(_public, 'web/css/logistics/view.less'), path.join(temp, 'web/css/logistics'));

});

gulp.task('web:css:logistics:choice-province', function(cb) {
    return task(path.join(_public, 'web/css/logistics/choice-province.less'), path.join(temp, 'web/css/logistics'));

});

gulp.task('web:css:order:index', function(cb) {
    return task(path.join(_public, 'web/css/order/index.less'), path.join(temp, 'web/css/order'));

});

gulp.task('web:css:order:view', function(cb) {
    return task(path.join(_public, 'web/css/order/view.less'), path.join(temp, 'web/css/order'));

});

gulp.task('web:css:realname:index', function(cb) {
    return task(path.join(_public, 'web/css/realname/index.less'), path.join(temp, 'web/css/realname'));

});

gulp.task('web:css:article:index', function(cb) {
    return task(path.join(_public, 'web/css/article/index.less'), path.join(temp, 'web/css/article'));

});

gulp.task('web:css:article:view', function(cb) {
    return task(path.join(_public, 'web/css/article/view.less'), path.join(temp, 'web/css/article'));

});

gulp.task('web:css:recharge:index', function(cb) {
    return task(path.join(_public, 'web/css/recharge/index.less'), path.join(temp, 'web/css/recharge'));

});

gulp.task('web:css:agent:index', function(cb) {
    return task(path.join(_public, 'web/css/agent/index.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:agent:aview', function(cb) {
    return task(path.join(_public, 'web/css/agent/aview.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:agent:distributor', function(cb) {
    return task(path.join(_public, 'web/css/agent/distributor.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:agent:dview', function(cb) {
    return task(path.join(_public, 'web/css/agent/dview.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:agent:commission', function(cb) {
    return task(path.join(_public, 'web/css/agent/commission.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:agent:withdraws', function(cb) {
    return task(path.join(_public, 'web/css/agent/withdraws.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:agent:choice', function(cb) {
    return task(path.join(_public, 'web/css/agent/choice.less'), path.join(temp, 'web/css/agent'));

});

gulp.task('web:css:supplier:index', function(cb) {
    return task(path.join(_public, 'web/css/supplier/index.less'), path.join(temp, 'web/css/supplier'));

});

gulp.task('web:css:supplier:goods', function(cb) {
    return task(path.join(_public, 'web/css/supplier/goods.less'), path.join(temp, 'web/css/supplier'));

});

gulp.task('web:css:supplier:goodsRelease', function(cb) {
    return task(path.join(_public, 'web/css/supplier/goodsRelease.less'), path.join(temp, 'web/css/supplier'));

});

gulp.task('web:css:supplier:order', function(cb) {
    return task(path.join(_public, 'web/css/supplier/order.less'), path.join(temp, 'web/css/supplier'));

});

gulp.task('web:css:supplier:orderView', function(cb) {
    return task(path.join(_public, 'web/css/supplier/orderView.less'), path.join(temp, 'web/css/supplier'));

});

gulp.task('web:css:supplier:view', function(cb) {
    return task(path.join(_public, 'web/css/supplier/view.less'), path.join(temp, 'web/css/supplier'));

});

gulp.task('web:css:advertising:top', function(cb) {
    return task(path.join(_public, 'web/css/advertising/top.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:slider', function(cb) {
    return task(path.join(_public, 'web/css/advertising/slider.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:sliderview', function(cb) {
    return task(path.join(_public, 'web/css/advertising/sliderview.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:article', function(cb) {
    return task(path.join(_public, 'web/css/advertising/article.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:articleview', function(cb) {
    return task(path.join(_public, 'web/css/advertising/articleview.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:news', function(cb) {
    return task(path.join(_public, 'web/css/advertising/news.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:newsview', function(cb) {
    return task(path.join(_public, 'web/css/advertising/newsview.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:category', function(cb) {
    return task(path.join(_public, 'web/css/advertising/category.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:categoryview', function(cb) {
    return task(path.join(_public, 'web/css/advertising/categoryview.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:categorychild', function(cb) {
    return task(path.join(_public, 'web/css/advertising/categorychild.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:goods', function(cb) {
    return task(path.join(_public, 'web/css/advertising/goods.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:goodsview', function(cb) {
    return task(path.join(_public, 'web/css/advertising/goodsview.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:item', function(cb) {
    return task(path.join(_public, 'web/css/advertising/item.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css:advertising:itemview', function(cb) {
    return task(path.join(_public, 'web/css/advertising/itemview.less'), path.join(temp, 'web/css/advertising'));

});

gulp.task('web:css', [
    'web:css:account:index',
    'web:css:account:member',
    'web:css:account:view',
    'web:css:admin:add',
    'web:css:admin:choice-authority',
    'web:css:admin:choice',
    'web:css:admin:edit',
    'web:css:admin:index',
    'web:css:admin:node',
    'web:css:article:index',
    'web:css:article:view',
    'web:css:finance:cash',
    'web:css:finance:recharge',
    'web:css:finance:transaction',
    'web:css:goods:category',
    'web:css:goods:choice-category',
    'web:css:goods:list',
    'web:css:goods:recycle',
    'web:css:goods:release',
    'web:css:goods:upload',
    'web:css:home:index',
    'web:css:homemanagement:goods',
    'web:css:homemanagement:goodsview',
    'web:css:homemanagement:groups',
    'web:css:homemanagement:index',
    'web:css:log:handle',
    'web:css:log:index',
    'web:css:logistics:index',
    'web:css:logistics:view',
    'web:css:logistics:choice-province',
    'web:css:order:index',
    'web:css:order:view',
    'web:css:permissions:add',
    'web:css:permissions:edit',
    'web:css:permissions:index',
    'web:css:realname:index',
    'web:css:recharge:index',
    'web:css:agent:index',
    'web:css:agent:aview',
    'web:css:agent:distributor',
    'web:css:agent:dview',
    'web:css:agent:commission',
    'web:css:agent:withdraws',
    'web:css:agent:choice',
    'web:css:supplier:index',
    'web:css:supplier:goods',
    'web:css:supplier:order',
    'web:css:supplier:view',
    'web:css:supplier:goodsRelease',
    'web:css:supplier:orderView',
    'web:css:advertising:top',
    'web:css:advertising:slider',
    'web:css:advertising:sliderview',
    'web:css:advertising:article',
    'web:css:advertising:articleview',
    'web:css:advertising:news',
    'web:css:advertising:newsview',
    'web:css:advertising:category',
    'web:css:advertising:categoryview',
    'web:css:advertising:categorychild',
    'web:css:advertising:goods',
    'web:css:advertising:goodsview',
    'web:css:advertising:item',
    'web:css:advertising:itemview'
]);


// 移动端静态js文件处理
gulp.task('web:script:require', function(cb) {
    // 加载器
    return gulp.src(path.join(_public, 'web/js/*.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js')))

});

gulp.task('web:script:account:index', function(cb) {
    // 普通用户列表页
    return gulp.src(path.join(_public, 'web/js/account/index.js'))
        .pipe(amdOptimize('../account/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/account')));

});

gulp.task('web:script:account:member', function(cb) {
    // 普通用户列表页
    return gulp.src(path.join(_public, 'web/js/account/member.js'))
        .pipe(amdOptimize('../account/member', opt))
        .pipe(uglify())
        .pipe(concat('member.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/account')));

});

gulp.task('web:script:account:view', function(cb) {
    // 编辑头像页
    return gulp.src(path.join(_public, 'web/js/account/view.js'))
        .pipe(amdOptimize('../account/view', opt))
        .pipe(uglify())
        .pipe(concat('view.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/account')));

});

gulp.task('web:script:admin:add', function(cb) {
    // 实名认证页
    return gulp.src(path.join(_public, 'web/js/admin/add.js'))
        .pipe(amdOptimize('../admin/add', opt))
        .pipe(uglify())
        .pipe(concat('add.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/admin')));

});

gulp.task('web:script:admin:choice-authority', function(cb) {
    // 选择修改密码方式页
    return gulp.src(path.join(_public, 'web/js/admin/choice-authority.js'))
        .pipe(amdOptimize('../admin/choice-authority', opt))
        .pipe(uglify())
        .pipe(concat('choice-authority.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/admin')));

});

gulp.task('web:script:admin:choice', function(cb) {
    // 忘记密码页
    return gulp.src(path.join(_public, 'web/js/admin/choice.js'))
        .pipe(amdOptimize('../admin/choice', opt))
        .pipe(uglify())
        .pipe(concat('choice.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/admin')));

});

gulp.task('web:script:admin:edit', function(cb) {
    // 修改手机号码页
    return gulp.src(path.join(_public, 'web/js/admin/edit.js'))
        .pipe(amdOptimize('../admin/edit', opt))
        .pipe(uglify())
        .pipe(concat('edit.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/admin')));

});

gulp.task('web:script:admin:index', function(cb) {
    // 安全中心页
    return gulp.src(path.join(_public, 'web/js/admin/index.js'))
        .pipe(amdOptimize('../admin/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/admin')));

});

gulp.task('web:script:admin:node', function(cb) {
    // 旧密码修改密码页
    return gulp.src(path.join(_public, 'web/js/admin/node.js'))
        .pipe(amdOptimize('../admin/node', opt))
        .pipe(uglify())
        .pipe(concat('node.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/admin')));

});

gulp.task('web:script:home:index', function(cb) {
    // 平台管理首页
    return gulp.src(path.join(_public, 'web/js/home/index.js'))
        .pipe(amdOptimize('../home/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/home')));

});

gulp.task('web:script:log:handle', function(cb) {
    // 平台管理首页
    return gulp.src(path.join(_public, 'web/js/log/handle.js'))
        .pipe(amdOptimize('../log/handle', opt))
        .pipe(uglify())
        .pipe(concat('handle.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/log')));

});

gulp.task('web:script:log:index', function(cb) {
    // 平台管理首页
    return gulp.src(path.join(_public, 'web/js/log/index.js'))
        .pipe(amdOptimize('../log/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/log')));

});

gulp.task('web:script:permissions:add', function(cb) {
    return gulp.src(path.join(_public, 'web/js/permissions/add.js'))
        .pipe(amdOptimize('../permissions/add', opt))
        .pipe(uglify())
        .pipe(concat('add.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/permissions')));

});

gulp.task('web:script:permissions:edit', function(cb) {
    return gulp.src(path.join(_public, 'web/js/permissions/edit.js'))
        .pipe(amdOptimize('../permissions/edit', opt))
        .pipe(uglify())
        .pipe(concat('edit.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/permissions')));

});

gulp.task('web:script:permissions:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/permissions/index.js'))
        .pipe(amdOptimize('../permissions/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/permissions')));

});

gulp.task('web:script:finance:cash', function(cb) {
    return gulp.src(path.join(_public, 'web/js/finance/cash.js'))
        .pipe(amdOptimize('../finance/cash', opt))
        .pipe(uglify())
        .pipe(concat('cash.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/finance')));

});

gulp.task('web:script:finance:recharge', function(cb) {
    return gulp.src(path.join(_public, 'web/js/finance/recharge.js'))
        .pipe(amdOptimize('../finance/recharge', opt))
        .pipe(uglify())
        .pipe(concat('recharge.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/finance')));

});

gulp.task('web:script:finance:transaction', function(cb) {
    return gulp.src(path.join(_public, 'web/js/finance/transaction.js'))
        .pipe(amdOptimize('../finance/transaction', opt))
        .pipe(uglify())
        .pipe(concat('transaction.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/finance')));

});

gulp.task('web:script:goods:category', function(cb) {
    return gulp.src(path.join(_public, 'web/js/goods/category.js'))
        .pipe(amdOptimize('../goods/category', opt))
        .pipe(uglify())
        .pipe(concat('category.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/goods')));

});

gulp.task('web:script:goods:choice-category', function(cb) {
    return gulp.src(path.join(_public, 'web/js/goods/choice-category.js'))
        .pipe(amdOptimize('../goods/choice-category', opt))
        .pipe(uglify())
        .pipe(concat('choice-category.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/goods')));

});

gulp.task('web:script:goods:list', function(cb) {
    return gulp.src(path.join(_public, 'web/js/goods/list.js'))
        .pipe(amdOptimize('../goods/list', opt))
        .pipe(uglify())
        .pipe(concat('list.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/goods')));

});

gulp.task('web:script:goods:recycle', function(cb) {
    return gulp.src(path.join(_public, 'web/js/goods/recycle.js'))
        .pipe(amdOptimize('../goods/recycle', opt))
        .pipe(uglify())
        .pipe(concat('recycle.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/goods')));

});

gulp.task('web:script:goods:release', function(cb) {
    return gulp.src(path.join(_public, 'web/js/goods/release.js'))
        .pipe(amdOptimize('../goods/release', opt))
        .pipe(uglify())
        .pipe(concat('release.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/goods')));

});

gulp.task('web:script:goods:upload', function(cb) {
    return gulp.src(path.join(_public, 'web/js/goods/upload.js'))
        .pipe(amdOptimize('../goods/upload', opt))
        .pipe(uglify())
        .pipe(concat('upload.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/goods')));

});

gulp.task('web:script:homemanagement:goods', function(cb) {
    return gulp.src(path.join(_public, 'web/js/homemanagement/goods.js'))
        .pipe(amdOptimize('../homemanagement/goods', opt))
        .pipe(uglify())
        .pipe(concat('goods.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/homemanagement')));

});

gulp.task('web:script:homemanagement:goodsview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/homemanagement/goodsview.js'))
        .pipe(amdOptimize('../homemanagement/goodsview', opt))
        .pipe(uglify())
        .pipe(concat('goodsview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/homemanagement')));

});

gulp.task('web:script:homemanagement:groups', function(cb) {
    return gulp.src(path.join(_public, 'web/js/homemanagement/groups.js'))
        .pipe(amdOptimize('../homemanagement/groups', opt))
        .pipe(uglify())
        .pipe(concat('groups.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/homemanagement')));

});

gulp.task('web:script:homemanagement:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/homemanagement/index.js'))
        .pipe(amdOptimize('../homemanagement/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/homemanagement')));

});

gulp.task('web:script:logistics:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/logistics/index.js'))
        .pipe(amdOptimize('../logistics/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/logistics')));

});

gulp.task('web:script:logistics:view', function(cb) {
    return gulp.src(path.join(_public, 'web/js/logistics/view.js'))
        .pipe(amdOptimize('../logistics/view', opt))
        .pipe(uglify())
        .pipe(concat('view.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/logistics')));

});

gulp.task('web:script:logistics:choice-province', function(cb) {
    return gulp.src(path.join(_public, 'web/js/logistics/choice-province.js'))
        .pipe(amdOptimize('../logistics/choice-province', opt))
        .pipe(uglify())
        .pipe(concat('choice-province.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/logistics')));

});

gulp.task('web:script:order:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/order/index.js'))
        .pipe(amdOptimize('../order/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/order')));

});

gulp.task('web:script:order:view', function(cb) {
    return gulp.src(path.join(_public, 'web/js/order/view.js'))
        .pipe(amdOptimize('../order/view', opt))
        .pipe(uglify())
        .pipe(concat('view.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/order')));

});

gulp.task('web:script:realname:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/realname/index.js'))
        .pipe(amdOptimize('../realname/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/realname')));

});

gulp.task('web:script:article:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/article/index.js'))
        .pipe(amdOptimize('../article/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/article')));

});

gulp.task('web:script:article:view', function(cb) {
    return gulp.src(path.join(_public, 'web/js/article/view.js'))
        .pipe(amdOptimize('../article/view', opt))
        .pipe(uglify())
        .pipe(concat('view.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/article')));

});

gulp.task('web:script:recharge:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/recharge/index.js'))
        .pipe(amdOptimize('../recharge/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/recharge')));

});

gulp.task('web:script:agent:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/index.js'))
        .pipe(amdOptimize('../agent/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:agent:aview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/aview.js'))
        .pipe(amdOptimize('../agent/aview', opt))
        .pipe(uglify())
        .pipe(concat('aview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:agent:distributor', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/distributor.js'))
        .pipe(amdOptimize('../agent/distributor', opt))
        .pipe(uglify())
        .pipe(concat('distributor.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:agent:dview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/dview.js'))
        .pipe(amdOptimize('../agent/dview', opt))
        .pipe(uglify())
        .pipe(concat('dview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:agent:commission', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/commission.js'))
        .pipe(amdOptimize('../agent/commission', opt))
        .pipe(uglify())
        .pipe(concat('commission.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:agent:withdraws', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/withdraws.js'))
        .pipe(amdOptimize('../agent/withdraws', opt))
        .pipe(uglify())
        .pipe(concat('withdraws.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:agent:choice', function(cb) {
    return gulp.src(path.join(_public, 'web/js/agent/choice.js'))
        .pipe(amdOptimize('../agent/choice', opt))
        .pipe(uglify())
        .pipe(concat('choice.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/agent')));

});

gulp.task('web:script:supplier:index', function(cb) {
    return gulp.src(path.join(_public, 'web/js/supplier/index.js'))
        .pipe(amdOptimize('../supplier/index', opt))
        .pipe(uglify())
        .pipe(concat('index.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/supplier')));

});

gulp.task('web:script:supplier:goods', function(cb) {
    return gulp.src(path.join(_public, 'web/js/supplier/goods.js'))
        .pipe(amdOptimize('../supplier/goods', opt))
        .pipe(uglify())
        .pipe(concat('goods.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/supplier')));

});

gulp.task('web:script:supplier:goodsRelease', function(cb) {
    return gulp.src(path.join(_public, 'web/js/supplier/goodsRelease.js'))
        .pipe(amdOptimize('../supplier/goodsRelease', opt))
        .pipe(uglify())
        .pipe(concat('goodsRelease.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/supplier')));

});

gulp.task('web:script:supplier:order', function(cb) {
    return gulp.src(path.join(_public, 'web/js/supplier/order.js'))
        .pipe(amdOptimize('../supplier/order', opt))
        .pipe(uglify())
        .pipe(concat('order.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/supplier')));

});

gulp.task('web:script:supplier:orderView', function(cb) {
    return gulp.src(path.join(_public, 'web/js/supplier/orderView.js'))
        .pipe(amdOptimize('../supplier/orderView', opt))
        .pipe(uglify())
        .pipe(concat('orderView.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/supplier')));

});

gulp.task('web:script:supplier:view', function(cb) {
    return gulp.src(path.join(_public, 'web/js/supplier/view.js'))
        .pipe(amdOptimize('../supplier/view', opt))
        .pipe(uglify())
        .pipe(concat('view.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/supplier')));

});

gulp.task('web:script:advertising:top', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/top.js'))
        .pipe(amdOptimize('../advertising/top', opt))
        .pipe(uglify())
        .pipe(concat('top.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:slider', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/slider.js'))
        .pipe(amdOptimize('../advertising/slider', opt))
        .pipe(uglify())
        .pipe(concat('slider.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:sliderview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/sliderview.js'))
        .pipe(amdOptimize('../advertising/sliderview', opt))
        .pipe(uglify())
        .pipe(concat('sliderview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:article', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/article.js'))
        .pipe(amdOptimize('../advertising/article', opt))
        .pipe(uglify())
        .pipe(concat('article.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:articleview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/articleview.js'))
        .pipe(amdOptimize('../advertising/articleview', opt))
        .pipe(uglify())
        .pipe(concat('articleview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:news', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/news.js'))
        .pipe(amdOptimize('../advertising/news', opt))
        .pipe(uglify())
        .pipe(concat('news.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:newsview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/newsview.js'))
        .pipe(amdOptimize('../advertising/newsview', opt))
        .pipe(uglify())
        .pipe(concat('newsview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:category', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/category.js'))
        .pipe(amdOptimize('../advertising/category', opt))
        .pipe(uglify())
        .pipe(concat('category.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:categoryview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/categoryview.js'))
        .pipe(amdOptimize('../advertising/categoryview', opt))
        .pipe(uglify())
        .pipe(concat('categoryview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:categorychild', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/categorychild.js'))
        .pipe(amdOptimize('../advertising/categorychild', opt))
        .pipe(uglify())
        .pipe(concat('categorychild.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:goods', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/goods.js'))
        .pipe(amdOptimize('../advertising/goods', opt))
        .pipe(uglify())
        .pipe(concat('goods.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:goodsview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/goodsview.js'))
        .pipe(amdOptimize('../advertising/goodsview', opt))
        .pipe(uglify())
        .pipe(concat('goodsview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:item', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/item.js'))
        .pipe(amdOptimize('../advertising/item', opt))
        .pipe(uglify())
        .pipe(concat('item.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});

gulp.task('web:script:advertising:itemview', function(cb) {
    return gulp.src(path.join(_public, 'web/js/advertising/itemview.js'))
        .pipe(amdOptimize('../advertising/itemview', opt))
        .pipe(uglify())
        .pipe(concat('itemview.js'))
        .pipe(gulp.dest(path.join(temp, 'web/js/advertising')));

});


gulp.task('web:script', [
    'web:script:require',
    'web:script:account:index',
    'web:script:account:view',
    'web:script:admin:add',
    'web:script:admin:choice-authority',
    'web:script:admin:choice',
    'web:script:admin:edit',
    'web:script:admin:index',
    'web:script:admin:node',
    'web:script:home:index',
    'web:script:log:handle',
    'web:script:log:index',
    'web:script:permissions:add',
    'web:script:permissions:edit',
    'web:script:permissions:index',
    'web:script:finance:cash',
    'web:script:finance:recharge',
    'web:script:finance:transaction',
    'web:script:goods:category',
    'web:script:goods:choice-category',
    'web:script:goods:list',
    'web:script:goods:recycle',
    'web:script:goods:release',
    'web:script:goods:upload',
    'web:script:homemanagement:goods',
    'web:script:homemanagement:goodsview',
    'web:script:homemanagement:groups',
    'web:script:homemanagement:index',
    'web:script:logistics:index',
    'web:script:logistics:view',
    'web:script:logistics:choice-province',
    'web:script:order:index',
    'web:script:order:view',
    'web:script:realname:index',
    'web:script:article:index',
    'web:script:article:view',
    'web:script:recharge:index',
    'web:script:agent:index',
    'web:script:agent:aview',
    'web:script:agent:distributor',
    'web:script:agent:dview',
    'web:script:agent:commission',
    'web:script:agent:withdraws',
    'web:script:agent:choice',
    'web:script:supplier:index',
    'web:script:supplier:goods',
    'web:script:supplier:order',
    'web:script:supplier:view',
    'web:script:supplier:goodsRelease',
    'web:script:supplier:orderView',
    'web:script:advertising:top',
    'web:script:advertising:slider',
    'web:script:advertising:sliderview',
    'web:script:advertising:article',
    'web:script:advertising:articleview',
    'web:script:advertising:news',
    'web:script:advertising:newsview',
    'web:script:advertising:category',
    'web:script:advertising:categoryview',
    'web:script:advertising:categorychild',
    'web:script:advertising:goods',
    'web:script:advertising:goodsview',
    'web:script:advertising:item',
    'web:script:advertising:itemview'
]);



// 以md5重命名文件
gulp.task('web:rev:images', ['web:images'], function() {
    return gulp.src(path.join(temp, 'web/images/**/*'))
        .pipe(rev())
        .pipe(gulp.dest(path.join(built, 'web/images')));

});

gulp.task('web:rev:fonts', ['web:fonts'], function() {
    return gulp.src(path.join(temp, 'web/fonts/**/*'))
        .pipe(rev())
        .pipe(gulp.dest(path.join(built, 'web/fonts')));

});

gulp.task('web:rec:fonts:editor', function(cb) {
    return gulp.src(path.join(_public, 'web/css/wangEditor/css/fonts/**/*'))
        .pipe(gulp.dest(path.join(built, 'web/css/wangEditor/css/fonts/')));

});

gulp.task('web:rev:css', ['web:css'], function() {
    return gulp.src(path.join(temp, 'web/css/**/*.css'))
        .pipe(rev())
        .pipe(gulp.dest(path.join(built, 'web/css')));

});

gulp.task('web:rev:script', ['web:script'], function() {
    return gulp.src(path.join(temp, 'web/js/**/*.js'))
        .pipe(rev())
        .pipe(gulp.dest(path.join(built, 'web/js')));

});

gulp.task('web:rev:jade', [
    'web:images',
    'web:fonts',
    'web:css',
    'web:script'
], function() {
    return gulp.src(path.join(templates, '**/*.jade'))
        .pipe(revjade(revconf(temp)))
        .pipe(gulp.dest(templates));

});

// 以md5重命名文件
gulp.task('web:rev', [
    'web:rev:images',
    'web:rev:fonts',
    'web:rec:fonts:editor',
    'web:rev:css',
    'web:rev:script',
    'web:rev:jade'
], function() {
    return gulp.start('clean');

});



// 清理缓存处理文件
gulp.task('clean', function() {
    return gulp.src(temp)
        .pipe(clean({
            force: true
        }));

});


// 设置 web 任务, 此任务调用上面定义的 css 和  js 任务
gulp.task('web', [
    'web:images',
    'web:fonts',
    'web:css',
    'web:script',
    'web:rev'
]);

// 默认命令行
gulp.task('default', ['web']);
