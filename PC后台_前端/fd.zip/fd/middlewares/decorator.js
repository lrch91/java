var url = require('url');

var config = require('../config');

var redirect = function(fn, res) {
    return function(_url, host) {
        if (host) {
            var station = config.station;
            host = station[host] && station[host].url || host || '';

            _url = url.resolve(host, _url);

        };

        return fn.call(res, _url);

    };

};



module.exports = function decorator(req, res, next) {
    res.redirect = redirect(res.redirect, res);


    next();

};
