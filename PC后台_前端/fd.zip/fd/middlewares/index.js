var cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    compress = require('compression'),
    colors = require('colors'),
    useragent = require('express-useragent'),
    breadcrumbs = require('express-breadcrumbs'),
    morgan = require('morgan'),
    csurf = require('csurf'),
    busboy = require('connect-busboy');


var middlewares = require('../config').middlewares;


module.exports = function(app) {
    app.use(bodyParser.json()); // for parsing application/json
    app.use(bodyParser.urlencoded({
        extended: true
    })); // for parsing application/x-www-form-urlencoded

    app.use(useragent.express());
    app.use(breadcrumbs.init(), breadcrumbs.setHome({
        name: '首页'
    }));

    app.use(cookieParser());
    app.use(compress()); //gzip

    app.use(morgan(':method'.cyan + ' :url' + ' :status'.magenta + ' :response-time'.gray + ' ms [:date[iso]]'));

    for (var i in middlewares) {
        app.use(require('./' + middlewares[i]));

    };

    return function middlewares(req, res, next) {
        next();

    };

};
