var path = require('path');
var url = require('url');
var querystring = require('querystring');

var _ = require('lodash');

var store = require('../views/store');
var config = require('../config');

var station = config.station;

var _url = station.admin.url;


var _querystring = function(path, query) {
    query = query || {};

    for (var i in query) {
        if (!query[i] && typeof query[i] !== 0) delete query[i];

    };

    return url.format({
        pathname: path,
        query: query
    });

};

var redirect = function(_url, host) {
    if (!host) return _url;

    host = station[host] && station[host].url || host || '';

    return url.resolve(host, _url);

};

var pagination = function(p, length) {
    length = length || 0;
    p = parseInt(p) || 1;

    var cell = config.pages.cell;
    var limit = config.pages.limit;
    var max = config.pages.max;


    var _cell = [];
    var pre = (p - 1) < 1 ? 1 : p - 1;
    var count = Math.ceil(length / limit) || 1;


    for (var i = 0; i < cell; i++) {
        var c = p - Math.floor(cell / 2) + i;

        if (c > 0 && c <= max && c <= count) {
            _cell.push(c);

        };

    };

    return {
        p: p,
        pre: pre,
        count: count,
        next: count > p ? p + 1 : p,
        cell: _cell.length ? _cell : [1],
        total: length
    };

};

var isInArray = function(arr,str){
    for(var i=0;i<arr.length;i++){
        if(arr[i] == str){
            return i;
        }
    }
    return -1;
}
module.exports = function locals(req, res, next) {
    res.locals.config = config;
    res.locals.isInArray = isInArray;
    res.locals.originalUrl = url.resolve(_url, req.originalUrl);

    res.locals.imageMogr = store.imageMogr;
    res.locals.imageMogrByBatch = store.imageMogrByBatch;

    res.locals.referer = req.referer = req.headers.referer ? url.resolve(_url, req.headers.referer) : _url;

    res.locals.querystring = _querystring;
    res.locals._ = _;

    res.locals.redirect = redirect;
    res.locals.url = url;

    res.locals.breadcrumbs = req.breadcrumbs()

    req.pagination = pagination;


    next();

};
