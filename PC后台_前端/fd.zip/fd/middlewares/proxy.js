var http = require('http');
var querystring = require('querystring');

var debug = require('debug');
var error = debug('proxy:error');
var success = debug('proxy:success');

var config = require('../config');
var host = config.proxy.host;
var port = config.proxy.port;
var timeout = config.proxy.timeout;

module.exports = function proxy(req, res, next) {
    req.proxy = function(path, data, fn, method) {
        var contentType = req.headers['Content-Type'] || req.headers['content-type'];

        'string' === typeof fn && (method = fn);
        'function' === typeof data && (fn = data, data = '');
        'object' === typeof data && (data = querystring.stringify(data));

        method = (method && typeof method === 'string') ? method : 'GET';

        method === 'GET' && !/\?/.test(path) && (path = path + (data ? '?' + data : ''));

        if (!contentType) {
            switch (method.toLocaleUpperCase()) {
                case 'GET':
                    contentType = 'text/html; charset=utf-8';
                    break;

                case 'POST':
                    contentType = 'application/x-www-form-urlencoded; charset=UTF-8';

                    break;

            };

        };

        var options = {
            host: host, // 代理服务器地址
            port: port, // 代理服务器端口
            path: path,
            method: method
        };

        options.headers = {
            'Content-Type': contentType,
            'Accept-Charset': 'UTF-8',
            'X-Real-IP': req.ip,
            Cookie: req.headers.cookie || ''
        };

        var now = Date.now();

        var request = http.request(options, function(_res) {
            if (typeof fn === 'function') {
                var body = [];
                var _body = '';

                _res.on('data', function(d) {
                    body.push(d);

                }).on('end', function() {
                    var end = Date.now() - now;

                    body = Buffer.concat(body);

                    _body = body.toString();

                    if (_res.statusCode === 200) {
                        success('%s %s %s %s %s', method.cyan, request.path, _res.statusCode.toString().magenta, end.toString().gray + ' ms', 'proxy'.green);

                        try {
                            _body = JSON.parse(_body);

                        } catch (err) {

                        };

                        fn(_body, _res, body);


                    } else {
                        error('%s %s %s %s %s', method.cyan, request.path, _res.statusCode.toString().magenta, end.toString().gray + ' ms', 'proxy'.green);

                        var err = new Error(_body || _res.statusMessage);
                        err.status = _res.statusCode;

                        fn(err);

                    };

                    // request.abort();

                });

            } else {
                _res.pipe(res);

            };

        }).on('error', function(err) {
            err.status = err.status || 500;

            error('%s %s %s %s', method.cyan, request.path, err.status.toString().magenta, err.message.red);

            next(err);

        }).on('socket', function(socket) {
            socket.emit('agentRemove'); // 监听 socket 事件，在回调中派发 agentRemove 事件

        });

        request.setTimeout(timeout, function() {
            var err = new Error('Proxy Time-out');
            err.status = 408;

            request.socket.emit('error', err);

        });


        // body写入
        if (method === 'POST' && !/multipart\/form\-data/.test(contentType)) {
            request.write(data);
            request.end();

        } else {
            req.pipe(request);

        };

    };

    req.proxy.then = req.proxy.then || function(events, cb) {
        if (!events || !(events instanceof Array || typeof events === 'string')) return false;

        typeof events === 'string' && (events = events.split(' '));

        events = events.filter(function(v) {
            return v;

        }); //过滤空项

        var then = function(ev) {
            var index = events.indexOf(ev);
            var done = true;

            if (index >= 0) {
                events[index] = true;

            } else {
                return false;

            }


            for (var i = 0, len = events.length; i < len; i++) {
                if (typeof events[i] === 'string') {
                    done = false;

                    break;

                };


            };

            done && cb();

        };

        then.end = function() {
            cb();

        };

        return then;

    };

    next();

};
