var account = require('../views/account');


var auth = account.getUserInfoProxy(function auth(req, res, next) {
    res.locals.user = req.user;

    next();

});

auth = function(fn) {
    return function auth(req, res, next) {
        var arg = Array.prototype.slice.call(arguments);
        if (/\/api\//.test(req.originalUrl)) {
            next();

        } else {
            fn.apply(this, arg);

        };

    };

}(auth);

module.exports = auth
