var path = require('path');

module.exports = {
    name: '富岛农友后台管理系统', // 项目名字
    slogan: '富岛农友后台管理系统', // 项目名字
    description: '富岛农友后台管理系统', // 项目描述
    keywords: '富岛农友后台管理系统',

    secret: 'waqVEAaOLxUnkT1qaxJhMhcu6GwHsCMjnTwd3YxgYdF', //加密用盐
    proxy: {
        //host: '192.168.8.243',
        //port: 8680,
        host: 'backstage.cnooc-gxfd.com',
        port: '',
        timeout: 10000
    },
    pages: { //分页配置
        limit: 20,
        max: 70,
        cell: 5
    },
    staticstore: '',
    store: {
        protocol: 'http',
        host: 'ulishop.qiniudn.com'
    },

    routes: { //路由配置表
        index: 'home', //首页
        other: [
            'api',
            'account',
            'admin',
            'log',
            'login',
            'permissions',
            'finance',
            'realname',
            'goods',
            'recharge',
            'server',
            'order',
            'homemanagement',
            'article',
            'info',
            'agent',
            'member',
            'advertising',
            'game',
            'statistical',
            'social'
        ]
    },
    middlewares: [ //全局中间件表, 顺序勿动
        'prototype', //原型方法
        'decorator', //装饰器
        'locals', //模板渲染方法
        'proxy', //代理中间件
        'auth' //用户登录检查
    ],
    station: {
        www: { //主站
            url: 'http://192.168.8.244:8000/'
        },
        admin: {
            url: 'http://192.168.8.244:8001/'
        }
    }

};
